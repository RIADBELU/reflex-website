const menu = document.querySelector('.menu');
const nav = document.querySelector('.nav');

menu?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menu.classList.toggle('open', open);
  menu.setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menu?.classList.remove('open');
  menu?.setAttribute('aria-expanded', 'false');
}));

const toast = document.querySelector('.toast');
document.querySelector('.copy')?.addEventListener('click', async event => {
  const command = event.currentTarget.dataset.copy;
  try {
    await navigator.clipboard.writeText(command);
    event.currentTarget.textContent = 'Copied';
    toast.classList.add('show');
    setTimeout(() => {
      event.currentTarget.textContent = 'Copy';
      toast.classList.remove('show');
    }, 1600);
  } catch {
    event.currentTarget.textContent = 'Copy manually';
  }
});


// Keep the motion useful: it demonstrates the one command Reflex is built around.
const liveCommand = document.querySelector('#live-command');
const liveResult = document.querySelector('#live-result');
const commandText = '$ reflex run hello.rflx';
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function playTerminal() {
  if (!liveCommand || !liveResult) return;
  liveCommand.textContent = '';
  liveResult.textContent = '';
  liveResult.classList.remove('visible');
  if (reduceMotion) {
    liveCommand.textContent = commandText;
    liveResult.textContent = 'Hello, World!';
    liveResult.classList.add('visible');
    return;
  }
  let i = 0;
  const type = () => {
    liveCommand.textContent = commandText.slice(0, i++);
    if (i <= commandText.length) window.setTimeout(type, 35);
    else window.setTimeout(() => {
      liveResult.textContent = 'Hello, World!';
      liveResult.classList.add('visible');
    }, 300);
  };
  type();
}
playTerminal();

// Sections arrive quietly as the reader reaches them. This intentionally adds
// no motion to users who ask for reduced motion in their operating system.
const revealTargets = document.querySelectorAll(
  '.quiet-grid p, .section-title, .language-body, .status-layout > div, .status-list article, .install-section > div, .notes > div, .notes > p, .footer > *'
);
if (reduceMotion) {
  revealTargets.forEach(element => element.classList.add('in-view'));
} else if ('IntersectionObserver' in window) {
  const scrollObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        scrollObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -24px 0px' });
  revealTargets.forEach((element, index) => {
    element.classList.add('scroll-reveal');
    element.style.setProperty('--reveal-delay', `${Math.min(index % 3, 2) * 75}ms`);
    scrollObserver.observe(element);
  });
} else {
  revealTargets.forEach(element => element.classList.add('in-view'));
}


// Theme choice follows the system on first visit, then remembers a manual pick.
const themeButton = document.querySelector('.theme-toggle');
function setTheme(theme) {
  const dark = theme === 'dark';
  document.body.classList.toggle('dark', dark);
  if (!themeButton) return;
  themeButton.querySelector('.theme-symbol').textContent = dark ? '☀' : '◐';
  themeButton.querySelector('.theme-label').textContent = dark ? 'Light' : 'Dark';
  themeButton.setAttribute('aria-label', `Switch to ${dark ? 'light' : 'dark'} mode`);
}
let savedTheme;
try { savedTheme = localStorage.getItem('reflex-theme'); } catch (_) {}
setTheme(savedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
themeButton?.addEventListener('click', () => {
  const next = document.body.classList.contains('dark') ? 'light' : 'dark';
  setTheme(next);
  try { localStorage.setItem('reflex-theme', next); } catch (_) {}
});
