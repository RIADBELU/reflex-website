# JSON bridge worker used by bridge.rflx.
import json
import sys

request = json.loads(sys.stdin.read())
function = request.get("function")
args = request.get("args", [])

if function == "add":
    print(json.dumps({"result": sum(args)}))
elif function == "greet":
    print(json.dumps({"result": f"Hello, {args[0]} from Python"}))
else:
    print(json.dumps({"error": f"Unknown function: {function}"}))
