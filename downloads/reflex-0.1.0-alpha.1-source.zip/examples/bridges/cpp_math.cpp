// Compile with: g++ -std=c++17 cpp_math.cpp -o cpp_math
// This tiny dependency-free demo accepts the numeric add request only.
#include <iostream>
#include <regex>
#include <string>

int main() {
    std::string input((std::istreambuf_iterator<char>(std::cin)), {});
    if (input.find("\"function\": \"add\"") == std::string::npos &&
        input.find("\"function\":\"add\"") == std::string::npos) {
        std::cout << R"({"error":"This demo supports add only"})" << std::endl;
        return 0;
    }
    std::regex arguments(R"("args"\s*:\s*\[([^\]]*)\])");
    std::smatch group;
    if (!std::regex_search(input, group, arguments)) {
        std::cout << R"({"error":"No args array"})" << std::endl;
        return 0;
    }
    std::regex number(R"(-?\d+(?:\.\d+)?)");
    double total = 0;
    for (std::sregex_iterator it(group[1].first, group[1].second, number), end; it != end; ++it) {
        total += std::stod((*it).str());
    }
    std::cout << "{\"result\":" << total << "}" << std::endl;
}
