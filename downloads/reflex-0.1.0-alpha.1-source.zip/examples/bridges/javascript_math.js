// Node.js JSON bridge worker.
const fs = require("node:fs");
const request = JSON.parse(fs.readFileSync(0, "utf8"));

if (request.function === "add") {
  console.log(JSON.stringify({ result: request.args.reduce((sum, value) => sum + value, 0) }));
} else if (request.function === "greet") {
  console.log(JSON.stringify({ result: `Hello, ${request.args[0]} from JavaScript` }));
} else {
  console.log(JSON.stringify({ error: `Unknown function: ${request.function}` }));
}
