// .NET 6+ JSON bridge worker. Build it as a console app, then point
// connect("csharp", "path/to/CSharpBridge.dll") at the compiled DLL.
using System.Text.Json;

using var input = new StreamReader(Console.OpenStandardInput());
var request = JsonDocument.Parse(await input.ReadToEndAsync()).RootElement;
var function = request.GetProperty("function").GetString();
var args = request.GetProperty("args");

if (function == "add")
{
    var total = args.EnumerateArray().Sum(value => value.GetDouble());
    Console.WriteLine(JsonSerializer.Serialize(new { result = total }));
}
else
{
    Console.WriteLine(JsonSerializer.Serialize(new { error = $"Unknown function: {function}" }));
}
