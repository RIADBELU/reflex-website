-- Lua JSON bridge worker. Install lua-cjson first, for example:
-- luarocks install lua-cjson
local json = require("cjson")
local request = json.decode(io.read("*a"))

if request["function"] == "add" then
  local total = 0
  for _, value in ipairs(request.args) do total = total + value end
  print(json.encode({ result = total }))
else
  print(json.encode({ error = "Unknown function: " .. tostring(request["function"]) }))
end
