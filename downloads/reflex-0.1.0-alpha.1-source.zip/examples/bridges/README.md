# Reflex bridge examples

Every foreign worker reads one request on standard input and writes one JSON response on standard output:

```json
{"function":"add","args":[20,22]}
```

```json
{"result":42}
```

## Run a Python worker

From the repository root:

```bash
python -m reflex examples/bridges/bridge.rflx
```

## JavaScript / Node

```rflx
js = connect("javascript", "javascript_math.js")
print(js.call("add", 20, 22))
```

Run a `.rflx` file located in this directory so the worker path is relative to it. Node.js must be installed.

## Lua

```rflx
lua = connect("lua", "lua_math.lua")
print(lua.call("add", 20, 22))
```

The sample uses `lua-cjson`, which must be installed for the Lua runtime.

## C++

Compile the sample first:

```bash
g++ -std=c++17 cpp_math.cpp -o cpp_math
```

Then call the executable:

```rflx
cpp = connect("cpp", "cpp_math")
print(cpp.call("add", 20, 22))
```

## C#

Put `CSharpBridge.cs` in a .NET console project and build it. Point Reflex at the resulting `.dll`:

```rflx
cs = connect("csharp", "bin/Release/net8.0/CSharpBridge.dll")
print(cs.call("add", 20, 22))
```

## Other runtimes

Use `connect("command", "your-command --worker")` whenever a runtime is not built in. The command must follow the same JSON stdin/stdout protocol. This works with Java, Rust, Go, Deno, PHP, Ruby, and many other targets.

Foreign workers are local process execution. Only invoke trusted targets.
