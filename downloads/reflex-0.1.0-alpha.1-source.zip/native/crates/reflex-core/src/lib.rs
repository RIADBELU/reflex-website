//! Standalone Reflex language core.
//!
//! The crate intentionally has no third-party dependencies: the alpha CLI is a
//! single native Rust binary and does not require Python, Node, or a VM to run
//! ordinary `.rflx` programs.

use std::cell::RefCell;
use std::collections::HashMap;
use std::fmt;
use std::rc::Rc;

#[derive(Debug, Clone)]
pub struct ReflexError(pub String);

impl fmt::Display for ReflexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}
impl std::error::Error for ReflexError {}

type Result<T> = std::result::Result<T, ReflexError>;

#[derive(Debug, Clone, PartialEq)]
enum Kind {
    Let,
    Const,
    Fun,
    Return,
    If,
    Elif,
    Else,
    While,
    For,
    In,
    Break,
    Continue,
    True,
    False,
    Null,
    And,
    Or,
    Not,
    Ident(String),
    Number(f64),
    String(String),
    Template(String),
    LParen,
    RParen,
    LBracket,
    RBracket,
    Comma,
    Colon,
    Dot,
    Plus,
    Minus,
    Star,
    Slash,
    Percent,
    Assign,
    PlusAssign,
    MinusAssign,
    StarAssign,
    SlashAssign,
    Arrow,
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
    Newline,
    Indent,
    Dedent,
    Eof,
}

#[derive(Debug, Clone)]
struct Token {
    kind: Kind,
    line: usize,
    column: usize,
}

struct Lexer<'a> {
    source: &'a str,
    filename: &'a str,
    tokens: Vec<Token>,
    indents: Vec<usize>,
    group_depth: i32,
}

impl<'a> Lexer<'a> {
    fn new(source: &'a str, filename: &'a str) -> Self {
        Self {
            source,
            filename,
            tokens: vec![],
            indents: vec![0],
            group_depth: 0,
        }
    }

    fn lex(mut self) -> Result<Vec<Token>> {
        for (line_index, raw) in self
            .source
            .replace("\r\n", "\n")
            .replace('\r', "\n")
            .lines()
            .enumerate()
        {
            self.lex_line(raw, line_index + 1)?;
        }
        let last = self.source.lines().count() + 1;
        if self.group_depth != 0 {
            return self.error(last, 1, "unclosed grouping delimiter");
        }
        if !matches!(self.tokens.last().map(|t| &t.kind), Some(Kind::Newline)) {
            self.push(Kind::Newline, last, 1);
        }
        while self.indents.len() > 1 {
            self.indents.pop();
            self.push(Kind::Dedent, last, 1);
        }
        self.push(Kind::Eof, last, 1);
        Ok(self.tokens)
    }

    fn error<T>(&self, line: usize, column: usize, message: &str) -> Result<T> {
        Err(ReflexError(format!(
            "{}:{}:{}: {}",
            self.filename, line, column, message
        )))
    }
    fn push(&mut self, kind: Kind, line: usize, column: usize) {
        self.tokens.push(Token { kind, line, column });
    }

    fn lex_line(&mut self, raw: &str, line: usize) -> Result<()> {
        let leading = raw.len() - raw.trim_start_matches(' ').len();
        if raw[..leading].contains('\t') {
            return self.error(line, 1, "tabs are not allowed for indentation; use spaces");
        }
        let remainder = &raw[leading..];
        if remainder.is_empty() || remainder.starts_with('#') || remainder.starts_with("//") {
            return Ok(());
        }
        if self.group_depth == 0 {
            let current = *self.indents.last().unwrap();
            if leading > current {
                self.indents.push(leading);
                self.push(Kind::Indent, line, 1);
            } else {
                while leading < *self.indents.last().unwrap() {
                    self.indents.pop();
                    self.push(Kind::Dedent, line, 1);
                }
                if leading != *self.indents.last().unwrap() {
                    return self.error(line, 1, "inconsistent indentation");
                }
            }
        }

        let chars: Vec<char> = raw.chars().collect();
        let mut i = raw[..leading].chars().count();
        while i < chars.len() {
            let ch = chars[i];
            let column = i + 1;
            if ch == ' ' || ch == '\t' {
                i += 1;
                continue;
            }
            if ch == '#' || (ch == '/' && chars.get(i + 1) == Some(&'/')) {
                break;
            }
            if ch.is_ascii_alphabetic() || ch == '_' {
                let start = i;
                i += 1;
                while i < chars.len() && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') {
                    i += 1;
                }
                let word: String = chars[start..i].iter().collect();
                let kind = match word.as_str() {
                    "let" => Kind::Let,
                    "const" => Kind::Const,
                    "fun" => Kind::Fun,
                    "return" => Kind::Return,
                    "if" => Kind::If,
                    "elif" => Kind::Elif,
                    "else" => Kind::Else,
                    "while" => Kind::While,
                    "for" => Kind::For,
                    "in" => Kind::In,
                    "break" => Kind::Break,
                    "continue" => Kind::Continue,
                    "true" | "True" => Kind::True,
                    "false" | "False" => Kind::False,
                    "null" | "None" => Kind::Null,
                    "and" => Kind::And,
                    "or" => Kind::Or,
                    "not" => Kind::Not,
                    _ => Kind::Ident(word),
                };
                self.push(kind, line, column);
                continue;
            }
            if ch.is_ascii_digit()
                || (ch == '.' && chars.get(i + 1).is_some_and(|v| v.is_ascii_digit()))
            {
                let start = i;
                let mut dot = ch == '.';
                i += 1;
                while i < chars.len() && (chars[i].is_ascii_digit() || (chars[i] == '.' && !dot)) {
                    if chars[i] == '.' {
                        dot = true;
                    }
                    i += 1;
                }
                let text: String = chars[start..i].iter().collect();
                let number = text.parse::<f64>().map_err(|_| {
                    ReflexError(format!(
                        "{}:{}:{}: invalid number",
                        self.filename, line, column
                    ))
                })?;
                self.push(Kind::Number(number), line, column);
                continue;
            }
            if ch == '"' || ch == '\'' {
                let (value, next) = self.string(&chars, i, ch, line)?;
                self.push(Kind::String(value), line, column);
                i = next;
                continue;
            }
            if ch == '`' {
                let (value, next) = self.template(&chars, i, line)?;
                self.push(Kind::Template(value), line, column);
                i = next;
                continue;
            }
            let pair: String = chars.iter().skip(i).take(2).collect();
            let pair_kind = match pair.as_str() {
                "=>" => Some(Kind::Arrow),
                "==" => Some(Kind::Eq),
                "!=" => Some(Kind::Ne),
                "<=" => Some(Kind::Le),
                ">=" => Some(Kind::Ge),
                "+=" => Some(Kind::PlusAssign),
                "-=" => Some(Kind::MinusAssign),
                "*=" => Some(Kind::StarAssign),
                "/=" => Some(Kind::SlashAssign),
                _ => None,
            };
            if let Some(kind) = pair_kind {
                self.push(kind, line, column);
                i += 2;
                continue;
            }
            let kind = match ch {
                '(' => {
                    self.group_depth += 1;
                    Kind::LParen
                }
                ')' => {
                    self.group_depth -= 1;
                    Kind::RParen
                }
                '[' => {
                    self.group_depth += 1;
                    Kind::LBracket
                }
                ']' => {
                    self.group_depth -= 1;
                    Kind::RBracket
                }
                ',' => Kind::Comma,
                ':' => Kind::Colon,
                '.' => Kind::Dot,
                '+' => Kind::Plus,
                '-' => Kind::Minus,
                '*' => Kind::Star,
                '/' => Kind::Slash,
                '%' => Kind::Percent,
                '=' => Kind::Assign,
                '<' => Kind::Lt,
                '>' => Kind::Gt,
                _ => return self.error(line, column, &format!("unexpected character '{ch}'")),
            };
            if self.group_depth < 0 {
                return self.error(line, column, "closing delimiter without opener");
            }
            self.push(kind, line, column);
            i += 1;
        }
        if self.group_depth == 0
            && !matches!(self.tokens.last().map(|t| &t.kind), Some(Kind::Newline))
        {
            self.push(Kind::Newline, line, chars.len() + 1);
        }
        Ok(())
    }

    fn string(
        &self,
        chars: &[char],
        start: usize,
        quote: char,
        line: usize,
    ) -> Result<(String, usize)> {
        let mut i = start + 1;
        let mut out = String::new();
        while i < chars.len() {
            if chars[i] == quote {
                return Ok((out, i + 1));
            }
            if chars[i] == '\\' {
                i += 1;
                if i >= chars.len() {
                    return self.error(line, start + 1, "unfinished escape sequence");
                }
                out.push(match chars[i] {
                    'n' => '\n',
                    'r' => '\r',
                    't' => '\t',
                    other => other,
                });
                i += 1;
            } else {
                out.push(chars[i]);
                i += 1;
            }
        }
        self.error(line, start + 1, "unterminated string")
    }
    fn template(&self, chars: &[char], start: usize, line: usize) -> Result<(String, usize)> {
        let mut i = start + 1;
        let mut out = String::new();
        while i < chars.len() {
            if chars[i] == '`' {
                return Ok((out, i + 1));
            }
            if chars[i] == '\\' {
                i += 1;
                if i >= chars.len() {
                    return self.error(line, start + 1, "unfinished template escape");
                }
                out.push(match chars[i] {
                    'n' => '\n',
                    't' => '\t',
                    other => other,
                });
                i += 1;
            } else {
                out.push(chars[i]);
                i += 1;
            }
        }
        self.error(line, start + 1, "unterminated template string")
    }
}

#[derive(Debug, Clone)]
enum Expr {
    Null,
    Bool(bool),
    Number(f64),
    String(String),
    Template(String),
    Var(String),
    List(Vec<Expr>),
    Unary(Kind, Box<Expr>),
    Binary(Box<Expr>, Kind, Box<Expr>),
    Call(Box<Expr>, Vec<Expr>),
    Member(Box<Expr>, String),
    Function(FunctionAst),
}
#[derive(Debug, Clone)]
struct Parameter {
    name: String,
    default: Option<Expr>,
}
#[derive(Debug, Clone)]
struct FunctionAst {
    parameters: Vec<Parameter>,
    body: FunctionBody,
}
#[derive(Debug, Clone)]
enum FunctionBody {
    Expression(Box<Expr>),
    Block(Vec<Stmt>),
}
#[derive(Debug, Clone)]
enum Stmt {
    Declare {
        name: String,
        value: Expr,
        constant: bool,
    },
    Function {
        name: String,
        function: FunctionAst,
    },
    Return(Option<Expr>),
    If {
        branches: Vec<(Expr, Vec<Stmt>)>,
        otherwise: Option<Vec<Stmt>>,
    },
    While {
        condition: Expr,
        body: Vec<Stmt>,
    },
    For {
        name: String,
        iterable: Expr,
        body: Vec<Stmt>,
    },
    Break,
    Continue,
    Expr(Expr),
    Assign {
        name: String,
        op: Kind,
        value: Expr,
    },
}

struct Parser {
    tokens: Vec<Token>,
    current: usize,
}
impl Parser {
    fn new(tokens: Vec<Token>) -> Self {
        Self { tokens, current: 0 }
    }
    fn parse(mut self) -> Result<Vec<Stmt>> {
        let mut statements = vec![];
        self.skip_newlines();
        while !self.at(|k| matches!(k, Kind::Eof)) {
            statements.push(self.statement()?);
            self.skip_newlines();
        }
        Ok(statements)
    }
    fn statement(&mut self) -> Result<Stmt> {
        if self.looks_short_function() {
            let name = self.ident("expected a function name")?;
            let parameters = self.parameters()?;
            let body = self.function_body()?;
            return Ok(Stmt::Function {
                name,
                function: FunctionAst { parameters, body },
            });
        }
        if self.match_kind(|k| matches!(k, Kind::Let | Kind::Const)) {
            let constant = matches!(self.previous().kind, Kind::Const);
            let name = self.ident("expected name after declaration")?;
            self.consume(|k| matches!(k, Kind::Assign), "a declaration needs a value")?;
            let value = self.expression()?;
            self.end_statement()?;
            return Ok(Stmt::Declare {
                name,
                value,
                constant,
            });
        }
        if self.match_kind(|k| matches!(k, Kind::Fun)) {
            if !matches!(self.peek().kind, Kind::Ident(_)) {
                self.current -= 1;
            } else {
                let name = self.ident("expected function name")?;
                let parameters = self.parameters()?;
                let body = self.function_body()?;
                if matches!(body, FunctionBody::Expression(_)) {
                    self.end_statement()?;
                }
                return Ok(Stmt::Function {
                    name,
                    function: FunctionAst { parameters, body },
                });
            }
        }
        if self.match_kind(|k| matches!(k, Kind::Return)) {
            let value = if self.at(|k| matches!(k, Kind::Newline | Kind::Dedent | Kind::Eof)) {
                None
            } else {
                Some(self.expression()?)
            };
            self.end_statement()?;
            return Ok(Stmt::Return(value));
        }
        if self.match_kind(|k| matches!(k, Kind::If)) {
            return self.if_statement();
        }
        if self.match_kind(|k| matches!(k, Kind::While)) {
            let condition = self.expression()?;
            let body = self.suite()?;
            return Ok(Stmt::While { condition, body });
        }
        if self.match_kind(|k| matches!(k, Kind::For)) {
            let name = self.ident("expected loop variable")?;
            self.consume(
                |k| matches!(k, Kind::In),
                "expected 'in' after loop variable",
            )?;
            let iterable = self.expression()?;
            let body = self.suite()?;
            return Ok(Stmt::For {
                name,
                iterable,
                body,
            });
        }
        if self.match_kind(|k| matches!(k, Kind::Break)) {
            self.end_statement()?;
            return Ok(Stmt::Break);
        }
        if self.match_kind(|k| matches!(k, Kind::Continue)) {
            self.end_statement()?;
            return Ok(Stmt::Continue);
        }
        let expression = self.expression()?;
        if self.match_kind(|k| {
            matches!(
                k,
                Kind::Assign
                    | Kind::PlusAssign
                    | Kind::MinusAssign
                    | Kind::StarAssign
                    | Kind::SlashAssign
            )
        }) {
            let op = self.previous().kind.clone();
            let name = match expression {
                Expr::Var(name) => name,
                _ => return self.fail("assignment target must be a variable"),
            };
            let value = self.expression()?;
            self.end_statement()?;
            return Ok(Stmt::Assign { name, op, value });
        }
        self.end_statement()?;
        Ok(Stmt::Expr(expression))
    }
    fn if_statement(&mut self) -> Result<Stmt> {
        let condition = self.expression()?;
        let mut branches = vec![(condition, self.suite()?)];
        while self.match_kind(|k| matches!(k, Kind::Elif)) {
            let condition = self.expression()?;
            let body = self.suite()?;
            branches.push((condition, body));
        }
        let otherwise = if self.match_kind(|k| matches!(k, Kind::Else)) {
            Some(self.suite()?)
        } else {
            None
        };
        Ok(Stmt::If {
            branches,
            otherwise,
        })
    }
    fn suite(&mut self) -> Result<Vec<Stmt>> {
        self.consume(|k| matches!(k, Kind::Colon), "expected ':' before block")?;
        self.consume(
            |k| matches!(k, Kind::Newline),
            "a block begins on next line",
        )?;
        self.consume(|k| matches!(k, Kind::Indent), "expected indented block")?;
        let mut body = vec![];
        self.skip_newlines();
        while !self.at(|k| matches!(k, Kind::Dedent | Kind::Eof)) {
            body.push(self.statement()?);
            self.skip_newlines();
        }
        self.consume(|k| matches!(k, Kind::Dedent), "expected block end")?;
        Ok(body)
    }
    fn function_body(&mut self) -> Result<FunctionBody> {
        if self.match_kind(|k| matches!(k, Kind::Arrow)) {
            Ok(FunctionBody::Expression(Box::new(self.expression()?)))
        } else {
            Ok(FunctionBody::Block(self.suite()?))
        }
    }
    fn parameters(&mut self) -> Result<Vec<Parameter>> {
        self.consume(
            |k| matches!(k, Kind::LParen),
            "expected '(' before parameters",
        )?;
        let mut out = vec![];
        if !self.at(|k| matches!(k, Kind::RParen)) {
            loop {
                let name = self.ident("expected parameter name")?;
                let default = if self.match_kind(|k| matches!(k, Kind::Assign)) {
                    Some(self.expression()?)
                } else {
                    None
                };
                out.push(Parameter { name, default });
                if !self.match_kind(|k| matches!(k, Kind::Comma)) {
                    break;
                }
                if self.at(|k| matches!(k, Kind::RParen)) {
                    break;
                }
            }
        }
        self.consume(
            |k| matches!(k, Kind::RParen),
            "expected ')' after parameters",
        )?;
        Ok(out)
    }
    fn expression(&mut self) -> Result<Expr> {
        self.logic_or()
    }
    fn logic_or(&mut self) -> Result<Expr> {
        let mut left = self.logic_and()?;
        while self.match_kind(|k| matches!(k, Kind::Or)) {
            let op = self.previous().kind.clone();
            let right = self.logic_and()?;
            left = Expr::Binary(Box::new(left), op, Box::new(right));
        }
        Ok(left)
    }
    fn logic_and(&mut self) -> Result<Expr> {
        let mut left = self.equality()?;
        while self.match_kind(|k| matches!(k, Kind::And)) {
            let op = self.previous().kind.clone();
            let right = self.equality()?;
            left = Expr::Binary(Box::new(left), op, Box::new(right));
        }
        Ok(left)
    }
    fn equality(&mut self) -> Result<Expr> {
        let mut left = self.comparison()?;
        while self.match_kind(|k| matches!(k, Kind::Eq | Kind::Ne)) {
            let op = self.previous().kind.clone();
            let right = self.comparison()?;
            left = Expr::Binary(Box::new(left), op, Box::new(right));
        }
        Ok(left)
    }
    fn comparison(&mut self) -> Result<Expr> {
        let mut left = self.term()?;
        while self.match_kind(|k| matches!(k, Kind::Lt | Kind::Le | Kind::Gt | Kind::Ge | Kind::In))
        {
            let op = self.previous().kind.clone();
            let right = self.term()?;
            left = Expr::Binary(Box::new(left), op, Box::new(right));
        }
        Ok(left)
    }
    fn term(&mut self) -> Result<Expr> {
        let mut left = self.factor()?;
        while self.match_kind(|k| matches!(k, Kind::Plus | Kind::Minus)) {
            let op = self.previous().kind.clone();
            let right = self.factor()?;
            left = Expr::Binary(Box::new(left), op, Box::new(right));
        }
        Ok(left)
    }
    fn factor(&mut self) -> Result<Expr> {
        let mut left = self.unary()?;
        while self.match_kind(|k| matches!(k, Kind::Star | Kind::Slash | Kind::Percent)) {
            let op = self.previous().kind.clone();
            let right = self.unary()?;
            left = Expr::Binary(Box::new(left), op, Box::new(right));
        }
        Ok(left)
    }
    fn unary(&mut self) -> Result<Expr> {
        if self.match_kind(|k| matches!(k, Kind::Not | Kind::Minus | Kind::Plus)) {
            let op = self.previous().kind.clone();
            return Ok(Expr::Unary(op, Box::new(self.unary()?)));
        }
        self.call()
    }
    fn call(&mut self) -> Result<Expr> {
        let mut value = self.primary()?;
        loop {
            if self.match_kind(|k| matches!(k, Kind::LParen)) {
                let mut args = vec![];
                if !self.at(|k| matches!(k, Kind::RParen)) {
                    loop {
                        args.push(self.expression()?);
                        if !self.match_kind(|k| matches!(k, Kind::Comma)) {
                            break;
                        }
                        if self.at(|k| matches!(k, Kind::RParen)) {
                            break;
                        }
                    }
                }
                self.consume(
                    |k| matches!(k, Kind::RParen),
                    "expected ')' after arguments",
                )?;
                value = Expr::Call(Box::new(value), args);
            } else if self.match_kind(|k| matches!(k, Kind::Dot)) {
                let name = self.ident("expected property after '.'")?;
                value = Expr::Member(Box::new(value), name);
            } else {
                break;
            }
        }
        Ok(value)
    }
    fn primary(&mut self) -> Result<Expr> {
        let token = self.advance().clone();
        match token.kind {
            Kind::Number(n) => Ok(Expr::Number(n)),
            Kind::String(s) => Ok(Expr::String(s)),
            Kind::Template(s) => Ok(Expr::Template(s)),
            Kind::True => Ok(Expr::Bool(true)),
            Kind::False => Ok(Expr::Bool(false)),
            Kind::Null => Ok(Expr::Null),
            Kind::Ident(name) => Ok(Expr::Var(name)),
            Kind::LParen => {
                let expr = self.expression()?;
                self.consume(
                    |k| matches!(k, Kind::RParen),
                    "expected ')' after expression",
                )?;
                Ok(expr)
            }
            Kind::LBracket => {
                let mut values = vec![];
                if !self.at(|k| matches!(k, Kind::RBracket)) {
                    loop {
                        values.push(self.expression()?);
                        if !self.match_kind(|k| matches!(k, Kind::Comma)) {
                            break;
                        }
                        if self.at(|k| matches!(k, Kind::RBracket)) {
                            break;
                        }
                    }
                }
                self.consume(|k| matches!(k, Kind::RBracket), "expected ']' after list")?;
                Ok(Expr::List(values))
            }
            Kind::Fun => {
                let parameters = self.parameters()?;
                let body = self.function_body()?;
                Ok(Expr::Function(FunctionAst { parameters, body }))
            }
            _ => Err(ReflexError(format!(
                "{}:{}: expected expression",
                token.line, token.column
            ))),
        }
    }
    fn looks_short_function(&self) -> bool {
        if !matches!(self.peek().kind, Kind::Ident(_))
            || !matches!(
                self.tokens.get(self.current + 1).map(|t| &t.kind),
                Some(Kind::LParen)
            )
        {
            return false;
        }
        let mut depth = 0i32;
        for index in (self.current + 1)..self.tokens.len() {
            match self.tokens[index].kind {
                Kind::LParen => depth += 1,
                Kind::RParen => {
                    depth -= 1;
                    if depth == 0 {
                        return matches!(
                            self.tokens.get(index + 1).map(|t| &t.kind),
                            Some(Kind::Arrow | Kind::Colon)
                        );
                    }
                }
                Kind::Newline | Kind::Eof if depth == 0 => return false,
                _ => {}
            }
        }
        false
    }
    fn ident(&mut self, message: &str) -> Result<String> {
        match self.advance().kind.clone() {
            Kind::Ident(name) => Ok(name),
            _ => self.fail(message),
        }
    }
    fn end_statement(&mut self) -> Result<()> {
        if self.match_kind(|k| matches!(k, Kind::Newline)) {
            self.skip_newlines();
            Ok(())
        } else if self.at(|k| matches!(k, Kind::Dedent | Kind::Eof)) {
            Ok(())
        } else {
            self.fail("expected end of statement")
        }
    }
    fn skip_newlines(&mut self) {
        while self.match_kind(|k| matches!(k, Kind::Newline)) {}
    }
    fn at(&self, predicate: impl Fn(&Kind) -> bool) -> bool {
        predicate(&self.peek().kind)
    }
    fn match_kind(&mut self, predicate: impl Fn(&Kind) -> bool) -> bool {
        if predicate(&self.peek().kind) {
            self.current += 1;
            true
        } else {
            false
        }
    }
    fn consume(&mut self, predicate: impl Fn(&Kind) -> bool, message: &str) -> Result<Token> {
        if predicate(&self.peek().kind) {
            Ok(self.advance().clone())
        } else {
            self.fail(message)
        }
    }
    fn advance(&mut self) -> &Token {
        if !matches!(self.peek().kind, Kind::Eof) {
            self.current += 1;
        }
        &self.tokens[self.current - 1]
    }
    fn previous(&self) -> &Token {
        &self.tokens[self.current - 1]
    }
    fn peek(&self) -> &Token {
        &self.tokens[self.current]
    }
    fn fail<T>(&self, message: &str) -> Result<T> {
        let token = self.peek();
        Err(ReflexError(format!(
            "{}:{}: {}",
            token.line, token.column, message
        )))
    }
}

#[derive(Clone, Debug)]
pub enum Value {
    Null,
    Bool(bool),
    Number(f64),
    String(String),
    List(Rc<RefCell<Vec<Value>>>),
    Function(Rc<Function>),
    Builtin(&'static str),
    Method(Rc<Method>),
}
#[derive(Clone, Debug)]
pub struct Function {
    parameters: Vec<Parameter>,
    body: FunctionBody,
    closure: EnvRef,
}
#[derive(Clone, Debug)]
pub struct Method {
    receiver: Value,
    name: String,
}
#[derive(Clone, Debug)]
struct Binding {
    value: Value,
    constant: bool,
}
#[derive(Debug)]
struct Environment {
    values: HashMap<String, Binding>,
    parent: Option<EnvRef>,
}
type EnvRef = Rc<RefCell<Environment>>;

impl Environment {
    fn child(parent: EnvRef) -> EnvRef {
        Rc::new(RefCell::new(Self {
            values: HashMap::new(),
            parent: Some(parent),
        }))
    }
    fn root() -> EnvRef {
        Rc::new(RefCell::new(Self {
            values: HashMap::new(),
            parent: None,
        }))
    }
}
fn define(env: &EnvRef, name: String, value: Value, constant: bool) -> Result<()> {
    if env.borrow().values.contains_key(&name) {
        return Err(ReflexError(format!(
            "'{name}' is already declared in this scope"
        )));
    }
    env.borrow_mut()
        .values
        .insert(name, Binding { value, constant });
    Ok(())
}
fn get(env: &EnvRef, name: &str) -> Result<Value> {
    if let Some(value) = env.borrow().values.get(name) {
        return Ok(value.value.clone());
    }
    let parent = env.borrow().parent.clone();
    if let Some(parent) = parent {
        get(&parent, name)
    } else {
        Err(ReflexError(format!("unknown name '{name}'")))
    }
}
fn contains(env: &EnvRef, name: &str) -> bool {
    env.borrow().values.contains_key(name)
        || env
            .borrow()
            .parent
            .clone()
            .is_some_and(|parent| contains(&parent, name))
}
fn assign(env: &EnvRef, name: &str, value: Value) -> Result<()> {
    if env.borrow().values.contains_key(name) {
        let mut current = env.borrow_mut();
        let binding = current.values.get_mut(name).unwrap();
        if binding.constant {
            return Err(ReflexError(format!("cannot reassign const '{name}'")));
        }
        binding.value = value;
        return Ok(());
    }
    let parent = env.borrow().parent.clone();
    if let Some(parent) = parent {
        assign(&parent, name, value)
    } else {
        Err(ReflexError(format!("unknown name '{name}'")))
    }
}

#[derive(Debug)]
enum Flow {
    Value(Value),
    Return(Value),
    Break,
    Continue,
}

struct Evaluator {
    globals: EnvRef,
}
impl Evaluator {
    fn new() -> Result<Self> {
        let globals = Environment::root();
        for builtin in ["print", "range", "len", "str", "number"] {
            define(&globals, builtin.into(), Value::Builtin(builtin), true)?;
        }
        Ok(Self { globals })
    }
    fn execute(&mut self, statements: &[Stmt]) -> Result<Value> {
        match self.block(statements, self.globals.clone())? {
            Flow::Value(value) => Ok(value),
            Flow::Return(_) => Err(ReflexError("return is only valid inside a function".into())),
            Flow::Break | Flow::Continue => Err(ReflexError(
                "break/continue is only valid inside a loop".into(),
            )),
        }
    }
    fn block(&mut self, statements: &[Stmt], env: EnvRef) -> Result<Flow> {
        let mut result = Value::Null;
        for statement in statements {
            match self.statement(statement, env.clone())? {
                Flow::Value(value) => result = value,
                flow => return Ok(flow),
            }
        }
        Ok(Flow::Value(result))
    }
    fn statement(&mut self, statement: &Stmt, env: EnvRef) -> Result<Flow> {
        match statement {
            Stmt::Declare {
                name,
                value,
                constant,
            } => {
                let result = self.expr(value, env.clone())?;
                define(&env, name.clone(), result.clone(), *constant)?;
                Ok(Flow::Value(result))
            }
            Stmt::Function { name, function } => {
                let value = Value::Function(Rc::new(Function {
                    parameters: function.parameters.clone(),
                    body: function.body.clone(),
                    closure: env.clone(),
                }));
                define(&env, name.clone(), value.clone(), true)?;
                Ok(Flow::Value(value))
            }
            Stmt::Return(value) => Ok(Flow::Return(match value {
                Some(expr) => self.expr(expr, env)?,
                None => Value::Null,
            })),
            Stmt::Expr(expr) => Ok(Flow::Value(self.expr(expr, env)?)),
            Stmt::Assign { name, op, value } => {
                let mut result = self.expr(value, env.clone())?;
                if !matches!(op, Kind::Assign) {
                    let existing = get(&env, name)?;
                    let binary = match op {
                        Kind::PlusAssign => Kind::Plus,
                        Kind::MinusAssign => Kind::Minus,
                        Kind::StarAssign => Kind::Star,
                        Kind::SlashAssign => Kind::Slash,
                        _ => unreachable!(),
                    };
                    result = self.binary(&binary, existing, result)?;
                }
                if contains(&env, name) {
                    assign(&env, name, result.clone())?;
                } else {
                    define(&env, name.clone(), result.clone(), false)?;
                }
                Ok(Flow::Value(result))
            }
            Stmt::If {
                branches,
                otherwise,
            } => {
                for (condition, body) in branches {
                    if truthy(&self.expr(condition, env.clone())?) {
                        return self.block(body, Environment::child(env));
                    }
                }
                if let Some(body) = otherwise {
                    self.block(body, Environment::child(env))
                } else {
                    Ok(Flow::Value(Value::Null))
                }
            }
            Stmt::While { condition, body } => {
                let mut result = Value::Null;
                while truthy(&self.expr(condition, env.clone())?) {
                    match self.block(body, Environment::child(env.clone()))? {
                        Flow::Value(value) => result = value,
                        Flow::Break => break,
                        Flow::Continue => continue,
                        flow @ Flow::Return(_) => return Ok(flow),
                    }
                }
                Ok(Flow::Value(result))
            }
            Stmt::For {
                name,
                iterable,
                body,
            } => {
                let items = match self.expr(iterable, env.clone())? {
                    Value::List(items) => items.borrow().clone(),
                    Value::String(text) => {
                        text.chars().map(|v| Value::String(v.to_string())).collect()
                    }
                    _ => return Err(ReflexError("for expects a list or string".into())),
                };
                let mut result = Value::Null;
                for item in items {
                    let local = Environment::child(env.clone());
                    define(&local, name.clone(), item, false)?;
                    match self.block(body, local)? {
                        Flow::Value(value) => result = value,
                        Flow::Break => break,
                        Flow::Continue => continue,
                        flow @ Flow::Return(_) => return Ok(flow),
                    }
                }
                Ok(Flow::Value(result))
            }
            Stmt::Break => Ok(Flow::Break),
            Stmt::Continue => Ok(Flow::Continue),
        }
    }
    fn expr(&mut self, expr: &Expr, env: EnvRef) -> Result<Value> {
        match expr {
            Expr::Null => Ok(Value::Null),
            Expr::Bool(v) => Ok(Value::Bool(*v)),
            Expr::Number(v) => Ok(Value::Number(*v)),
            Expr::String(v) => Ok(Value::String(v.clone())),
            Expr::Template(v) => self.interpolate(v, env),
            Expr::Var(name) => get(&env, name),
            Expr::List(values) => Ok(Value::List(Rc::new(RefCell::new(
                values
                    .iter()
                    .map(|value| self.expr(value, env.clone()))
                    .collect::<Result<Vec<_>>>()?,
            )))),
            Expr::Function(function) => Ok(Value::Function(Rc::new(Function {
                parameters: function.parameters.clone(),
                body: function.body.clone(),
                closure: env,
            }))),
            Expr::Unary(op, value) => {
                let value = self.expr(value, env)?;
                match op {
                    Kind::Not => Ok(Value::Bool(!truthy(&value))),
                    Kind::Minus => match value {
                        Value::Number(v) => Ok(Value::Number(-v)),
                        _ => Err(ReflexError("unary - needs a number".into())),
                    },
                    Kind::Plus => match value {
                        Value::Number(v) => Ok(Value::Number(v)),
                        _ => Err(ReflexError("unary + needs a number".into())),
                    },
                    _ => unreachable!(),
                }
            }
            Expr::Binary(left, op, right) => {
                let left = self.expr(left, env.clone())?;
                if matches!(op, Kind::And) {
                    return if truthy(&left) {
                        self.expr(right, env)
                    } else {
                        Ok(left)
                    };
                }
                if matches!(op, Kind::Or) {
                    return if truthy(&left) {
                        Ok(left)
                    } else {
                        self.expr(right, env)
                    };
                }
                let right = self.expr(right, env)?;
                self.binary(op, left, right)
            }
            Expr::Call(callee, args) => {
                let callee = self.expr(callee, env.clone())?;
                let args = args
                    .iter()
                    .map(|arg| self.expr(arg, env.clone()))
                    .collect::<Result<Vec<_>>>()?;
                self.call(callee, args)
            }
            Expr::Member(object, name) => {
                let receiver = self.expr(object, env)?;
                self.member(receiver, name)
            }
        }
    }
    fn binary(&self, op: &Kind, left: Value, right: Value) -> Result<Value> {
        match op {
            Kind::Plus => {
                if matches!(left, Value::String(_)) || matches!(right, Value::String(_)) {
                    Ok(Value::String(format!(
                        "{}{}",
                        stringify(&left),
                        stringify(&right)
                    )))
                } else {
                    number_pair(left, right, |a, b| a + b)
                }
            }
            Kind::Minus => number_pair(left, right, |a, b| a - b),
            Kind::Star => number_pair(left, right, |a, b| a * b),
            Kind::Slash => number_pair(left, right, |a, b| a / b),
            Kind::Percent => number_pair(left, right, |a, b| a % b),
            Kind::Eq => Ok(Value::Bool(equals(&left, &right))),
            Kind::Ne => Ok(Value::Bool(!equals(&left, &right))),
            Kind::Lt => compare_pair(left, right, |a, b| a < b),
            Kind::Le => compare_pair(left, right, |a, b| a <= b),
            Kind::Gt => compare_pair(left, right, |a, b| a > b),
            Kind::Ge => compare_pair(left, right, |a, b| a >= b),
            Kind::In => match right {
                Value::List(items) => Ok(Value::Bool(
                    items.borrow().iter().any(|item| equals(item, &left)),
                )),
                Value::String(text) => Ok(Value::Bool(text.contains(&stringify(&left)))),
                _ => Err(ReflexError(
                    "right side of 'in' must be list or string".into(),
                )),
            },
            _ => Err(ReflexError("unsupported binary operator".into())),
        }
    }
    fn call(&mut self, callee: Value, args: Vec<Value>) -> Result<Value> {
        match callee {
            Value::Builtin(name) => self.builtin(name, args),
            Value::Method(method) => self.method(&method, args),
            Value::Function(function) => self.function(&function, args),
            _ => Err(ReflexError(format!(
                "{} is not callable",
                stringify(&callee)
            ))),
        }
    }
    fn builtin(&mut self, name: &str, args: Vec<Value>) -> Result<Value> {
        match name {
            "print" => {
                println!(
                    "{}",
                    args.iter().map(stringify).collect::<Vec<_>>().join(" ")
                );
                Ok(Value::Null)
            }
            "len" => {
                if args.len() != 1 {
                    return Err(ReflexError("len expects one argument".into()));
                }
                match &args[0] {
                    Value::String(v) => Ok(Value::Number(v.chars().count() as f64)),
                    Value::List(v) => Ok(Value::Number(v.borrow().len() as f64)),
                    _ => Err(ReflexError("len expects string or list".into())),
                }
            }
            "str" => one_arg(name, args).map(|v| Value::String(stringify(&v))),
            "number" => {
                let value = one_arg(name, args)?;
                match value {
                    Value::Number(n) => Ok(Value::Number(n)),
                    Value::String(text) => text
                        .parse::<f64>()
                        .map(Value::Number)
                        .map_err(|_| ReflexError("number needs a numeric string".into())),
                    _ => Err(ReflexError("number needs a number or string".into())),
                }
            }
            "range" => {
                if args.is_empty() || args.len() > 3 {
                    return Err(ReflexError("range expects 1 to 3 numbers".into()));
                }
                let (mut start, end, step) = match args.len() {
                    1 => (0.0, as_number(&args[0])?, 1.0),
                    2 => (as_number(&args[0])?, as_number(&args[1])?, 1.0),
                    _ => (
                        as_number(&args[0])?,
                        as_number(&args[1])?,
                        as_number(&args[2])?,
                    ),
                };
                if step == 0.0 {
                    return Err(ReflexError("range step cannot be zero".into()));
                }
                let mut out = vec![];
                while if step > 0.0 { start < end } else { start > end } {
                    out.push(Value::Number(start));
                    start += step;
                }
                Ok(Value::List(Rc::new(RefCell::new(out))))
            }
            _ => Err(ReflexError(format!("unknown builtin '{name}'"))),
        }
    }
    fn member(&self, receiver: Value, name: &str) -> Result<Value> {
        match (&receiver, name) {
            (Value::List(items), "length") => Ok(Value::Number(items.borrow().len() as f64)),
            (Value::String(text), "length") => Ok(Value::Number(text.chars().count() as f64)),
            (
                Value::List(_),
                "map" | "filter" | "join" | "push" | "pop" | "includes" | "first" | "last",
            )
            | (Value::String(_), "upper" | "lower" | "trim" | "split" | "includes" | "replace") => {
                Ok(Value::Method(Rc::new(Method {
                    receiver,
                    name: name.into(),
                })))
            }
            _ => Err(ReflexError(format!(
                "{} has no property '{name}'",
                kind_name(&receiver)
            ))),
        }
    }
    fn method(&mut self, method: &Method, args: Vec<Value>) -> Result<Value> {
        match (&method.receiver, method.name.as_str()) {
            (Value::List(items), "join") => {
                let separator = if args.is_empty() {
                    ",".into()
                } else {
                    stringify(&one_arg("join", args)?)
                };
                Ok(Value::String(
                    items
                        .borrow()
                        .iter()
                        .map(stringify)
                        .collect::<Vec<_>>()
                        .join(&separator),
                ))
            }
            (Value::List(items), "map") => {
                let fn_value = one_arg("map", args)?;
                let values = items
                    .borrow()
                    .clone()
                    .into_iter()
                    .map(|item| self.call(fn_value.clone(), vec![item]))
                    .collect::<Result<Vec<_>>>()?;
                Ok(Value::List(Rc::new(RefCell::new(values))))
            }
            (Value::List(items), "filter") => {
                let fn_value = one_arg("filter", args)?;
                let mut output = vec![];
                for item in items.borrow().clone() {
                    if truthy(&self.call(fn_value.clone(), vec![item.clone()])?) {
                        output.push(item);
                    }
                }
                Ok(Value::List(Rc::new(RefCell::new(output))))
            }
            (Value::List(items), "push") => {
                items.borrow_mut().extend(args);
                Ok(Value::Number(items.borrow().len() as f64))
            }
            (Value::List(items), "pop") => {
                if !args.is_empty() {
                    return Err(ReflexError("pop expects no arguments".into()));
                }
                Ok(items.borrow_mut().pop().unwrap_or(Value::Null))
            }
            (Value::List(items), "includes") => {
                let item = one_arg("includes", args)?;
                Ok(Value::Bool(
                    items.borrow().iter().any(|value| equals(value, &item)),
                ))
            }
            (Value::List(items), "first") => {
                if !args.is_empty() {
                    return Err(ReflexError("first expects no arguments".into()));
                }
                Ok(items.borrow().first().cloned().unwrap_or(Value::Null))
            }
            (Value::List(items), "last") => {
                if !args.is_empty() {
                    return Err(ReflexError("last expects no arguments".into()));
                }
                Ok(items.borrow().last().cloned().unwrap_or(Value::Null))
            }
            (Value::String(text), "upper") => Ok(Value::String(text.to_uppercase())),
            (Value::String(text), "lower") => Ok(Value::String(text.to_lowercase())),
            (Value::String(text), "trim") => Ok(Value::String(text.trim().into())),
            (Value::String(text), "split") => {
                let separator = if args.is_empty() {
                    None
                } else {
                    Some(stringify(&one_arg("split", args)?))
                };
                Ok(Value::List(Rc::new(RefCell::new(match separator {
                    Some(separator) => text
                        .split(&separator)
                        .map(|v| Value::String(v.into()))
                        .collect(),
                    None => text
                        .split_whitespace()
                        .map(|v| Value::String(v.into()))
                        .collect(),
                }))))
            }
            (Value::String(text), "includes") => Ok(Value::Bool(
                text.contains(&stringify(&one_arg("includes", args)?)),
            )),
            (Value::String(text), "replace") => {
                if args.len() != 2 {
                    return Err(ReflexError("replace expects two arguments".into()));
                }
                Ok(Value::String(
                    text.replace(&stringify(&args[0]), &stringify(&args[1])),
                ))
            }
            _ => Err(ReflexError(format!("unknown method {}", method.name))),
        }
    }
    fn function(&mut self, function: &Function, args: Vec<Value>) -> Result<Value> {
        if args.len() > function.parameters.len() {
            return Err(ReflexError(format!(
                "function expected at most {} arguments",
                function.parameters.len()
            )));
        }
        let local = Environment::child(function.closure.clone());
        for (index, parameter) in function.parameters.iter().enumerate() {
            let value = if let Some(value) = args.get(index) {
                value.clone()
            } else if let Some(default) = &parameter.default {
                self.expr(default, local.clone())?
            } else {
                return Err(ReflexError(format!(
                    "missing required argument '{}'",
                    parameter.name
                )));
            };
            define(&local, parameter.name.clone(), value, false)?;
        }
        match &function.body {
            FunctionBody::Expression(expr) => self.expr(expr, local),
            FunctionBody::Block(block) => match self.block(block, local)? {
                Flow::Return(value) | Flow::Value(value) => Ok(value),
                Flow::Break | Flow::Continue => {
                    Err(ReflexError("break/continue outside loop".into()))
                }
            },
        }
    }
    fn interpolate(&mut self, template: &str, env: EnvRef) -> Result<Value> {
        let mut output = String::new();
        let mut remaining = template;
        while let Some(start) = remaining.find("${") {
            output.push_str(&remaining[..start]);
            let after = &remaining[start + 2..];
            let Some(end) = after.find('}') else {
                return Err(ReflexError("unterminated template interpolation".into()));
            };
            let expression = parse_expression(&after[..end])?;
            output.push_str(&stringify(&self.expr(&expression, env.clone())?));
            remaining = &after[end + 1..];
        }
        output.push_str(remaining);
        Ok(Value::String(output))
    }
}

fn one_arg(name: &str, args: Vec<Value>) -> Result<Value> {
    if args.len() != 1 {
        Err(ReflexError(format!("{name} expects one argument")))
    } else {
        Ok(args.into_iter().next().unwrap())
    }
}
fn as_number(value: &Value) -> Result<f64> {
    if let Value::Number(v) = value {
        Ok(*v)
    } else {
        Err(ReflexError("expected number".into()))
    }
}
fn number_pair(left: Value, right: Value, op: impl Fn(f64, f64) -> f64) -> Result<Value> {
    Ok(Value::Number(op(as_number(&left)?, as_number(&right)?)))
}
fn compare_pair(left: Value, right: Value, op: impl Fn(f64, f64) -> bool) -> Result<Value> {
    Ok(Value::Bool(op(as_number(&left)?, as_number(&right)?)))
}
fn truthy(value: &Value) -> bool {
    match value {
        Value::Null => false,
        Value::Bool(v) => *v,
        Value::Number(v) => *v != 0.0,
        Value::String(v) => !v.is_empty(),
        Value::List(v) => !v.borrow().is_empty(),
        _ => true,
    }
}
fn equals(a: &Value, b: &Value) -> bool {
    match (a, b) {
        (Value::Null, Value::Null) => true,
        (Value::Bool(a), Value::Bool(b)) => a == b,
        (Value::Number(a), Value::Number(b)) => (*a - *b).abs() < f64::EPSILON,
        (Value::String(a), Value::String(b)) => a == b,
        (Value::List(a), Value::List(b)) => {
            let a = a.borrow();
            let b = b.borrow();
            a.len() == b.len() && a.iter().zip(b.iter()).all(|(x, y)| equals(x, y))
        }
        _ => false,
    }
}
fn kind_name(value: &Value) -> &'static str {
    match value {
        Value::Null => "null",
        Value::Bool(_) => "boolean",
        Value::Number(_) => "number",
        Value::String(_) => "string",
        Value::List(_) => "list",
        Value::Function(_) => "function",
        Value::Builtin(_) => "builtin",
        Value::Method(_) => "method",
    }
}
pub fn stringify(value: &Value) -> String {
    match value {
        Value::Null => "null".into(),
        Value::Bool(v) => v.to_string(),
        Value::Number(v) => {
            if v.fract() == 0.0 {
                format!("{}", *v as i64)
            } else {
                v.to_string()
            }
        }
        Value::String(v) => v.clone(),
        Value::List(values) => format!(
            "[{}]",
            values
                .borrow()
                .iter()
                .map(stringify)
                .collect::<Vec<_>>()
                .join(",")
        ),
        Value::Function(_) => "<function>".into(),
        Value::Builtin(name) => format!("<builtin {name}>"),
        Value::Method(_) => "<method>".into(),
    }
}

fn parse_expression(source: &str) -> Result<Expr> {
    let tokens = Lexer::new(source, "<template>").lex()?;
    let mut parser = Parser::new(tokens);
    let expr = parser.expression()?;
    if !parser.at(|k| matches!(k, Kind::Newline | Kind::Eof)) {
        return parser.fail("template interpolation needs one expression");
    }
    Ok(expr)
}

/// Checks syntax without executing the file.
pub fn check_source(source: &str, filename: &str) -> Result<()> {
    Parser::new(Lexer::new(source, filename).lex()?)
        .parse()
        .map(|_| ())
}
/// Runs a Reflex source file using the standalone native evaluator.
pub fn run_source(source: &str, filename: &str) -> Result<Value> {
    let program = Parser::new(Lexer::new(source, filename).lex()?).parse()?;
    Evaluator::new()?.execute(&program)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn run(source: &str) -> Value {
        run_source(source, "<test>").unwrap()
    }

    #[test]
    fn simple_bindings_and_math() {
        assert_eq!(stringify(&run("value = 20 + 22\nvalue")), "42");
    }
    #[test]
    fn bare_function_and_template() {
        assert_eq!(
            stringify(&run(r#"greet(name) => `Hello, ${name}!`
greet("Reflex")"#)),
            "Hello, Reflex!"
        );
    }
    #[test]
    fn blocks_and_for() {
        assert_eq!(
            stringify(&run(
                "sum = 0\nfor number in range(1, 5):\n    sum += number\nsum"
            )),
            "10"
        );
    }
    #[test]
    fn maps_and_defaults() {
        assert_eq!(
            stringify(&run(r#"square(n) => n * n
range(1, 4).map(square).join(", ")"#)),
            "1, 4, 9"
        );
    }
    #[test]
    fn const_cannot_change() {
        assert!(run_source("const name = \"x\"\nname = \"y\"", "<test>").is_err());
    }
}
