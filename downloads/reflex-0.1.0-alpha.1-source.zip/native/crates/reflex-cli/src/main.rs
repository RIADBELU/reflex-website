use std::env;
use std::fs;
use std::path::Path;
use std::process::ExitCode;

fn help() {
    println!(
        "Reflex {}\n\nUSAGE:\n  reflex <file.rflx>\n  reflex run <file.rflx>\n  reflex check <file.rflx>\n  reflex --version\n\nThe standalone alpha runs the core Reflex language without Python.",
        env!("CARGO_PKG_VERSION")
    );
}

fn source(path: &str) -> Result<String, String> {
    if Path::new(path)
        .extension()
        .is_none_or(|extension| extension != "rflx")
    {
        eprintln!("warning: Reflex files conventionally use the .rflx extension");
    }
    fs::read_to_string(path).map_err(|error| format!("could not read {path}: {error}"))
}

fn main() -> ExitCode {
    let mut args = env::args().skip(1).collect::<Vec<_>>();
    if args.is_empty() || matches!(args.first().map(String::as_str), Some("-h" | "--help")) {
        help();
        return ExitCode::SUCCESS;
    }
    if matches!(args.first().map(String::as_str), Some("-V" | "--version")) {
        println!("reflex {}", env!("CARGO_PKG_VERSION"));
        return ExitCode::SUCCESS;
    }
    if !matches!(args.first().map(String::as_str), Some("run" | "check")) {
        args.insert(0, "run".into());
    }
    if args.len() != 2 {
        eprintln!("error: expected one .rflx file\n\nRun `reflex --help` for usage.");
        return ExitCode::from(2);
    }
    let command = &args[0];
    let file = &args[1];
    let input = match source(file) {
        Ok(input) => input,
        Err(error) => {
            eprintln!("Reflex error: {error}");
            return ExitCode::from(1);
        }
    };
    match command.as_str() {
        "check" => match reflex_core::check_source(&input, file) {
            Ok(()) => {
                println!("✓ {file}: valid Reflex syntax");
                ExitCode::SUCCESS
            }
            Err(error) => {
                eprintln!("Reflex error: {error}");
                ExitCode::from(1)
            }
        },
        "run" => match reflex_core::run_source(&input, file) {
            Ok(_) => ExitCode::SUCCESS,
            Err(error) => {
                eprintln!("Reflex error: {error}");
                ExitCode::from(1)
            }
        },
        _ => unreachable!(),
    }
}
