# Native Reflex roadmap

## v0.1 alpha — implemented baseline

- [x] Native `reflex run` / `reflex check` CLI
- [x] Standalone lexer, parser, evaluator, lexical environments, functions, loops, templates, lists, and collection methods
- [x] Build and test verification against `examples/hello.rflx`
- [x] Windows, macOS, Linux GitHub Actions build/test matrix
- [x] No Python dependency for ordinary core programs

## v0.2 — language parity

- [ ] Multiline strings and templates
- [ ] Objects, indexing, member assignment, imports/modules
- [ ] Source spans, stack traces, formatter, and stable error codes
- [ ] `reflex task` command registry for Reflex-defined build/dev/test tasks
- [ ] Snapshot conformance suite shared with the reference implementation

## v0.3 — application runtime

- [ ] Native JSON bridge process runner
- [ ] HTTP routing and static export
- [ ] HTML/CSS template assets
- [ ] Embedded desktop WebView target

## v1.0 — production readiness

- [ ] Package registry and lockfiles
- [ ] Async I/O and worker supervision
- [ ] Language server and debugger protocol
- [ ] Signed release binaries and installers for Windows, macOS, Linux
- [ ] Security model, compatibility policy, and long-term governance
