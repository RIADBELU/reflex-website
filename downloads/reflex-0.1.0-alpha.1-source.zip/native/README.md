# Reflex native runtime

This directory is the standalone Rust implementation of Reflex. It is separate from the original Python reference interpreter so the release CLI can run `.rflx` files without Python installed.

## Build locally

Install the stable Rust toolchain first if necessary:

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

Then build and run the standalone implementation:

```bash
cd native
cargo test --workspace
cargo run -p reflex-cli -- run ../examples/hello.rflx
cargo run -p reflex-cli -- check ../examples/hello.rflx
```

The resulting `reflex` program is a native executable. It does not bundle, import, or invoke Python to run ordinary Reflex core programs.

The release binary is `target/release/reflex` (`reflex.exe` on Windows):

```bash
cargo build --release -p reflex-cli
./target/release/reflex run path/to/app.rflx
```

## v0.1 alpha scope

The standalone alpha focuses on the language core and CLI: declarations, implicit bindings, functions, `if`, `while`, `for`, expressions, strings/templates, arrays, `range`, `print`, and useful collection methods. The Python runtime remains the feature-complete reference while the web, desktop, JSON bridge, module, LSP, and package systems are migrated in later releases.

The CI workflow builds and tests Windows, macOS, and Linux on every native-runtime change.
