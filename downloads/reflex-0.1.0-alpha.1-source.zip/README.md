# Reflex

**Reflex** is an experimental `.rflx` language for approachable full-stack and desktop projects. It uses Python's readable indentation, JavaScript-style template strings and collections, plus deliberately small syntax for connecting code across runtimes.

> **Prototype status:** This is a working reference interpreter and local-development runtime—not a hardened production framework or a complete compiler yet.

## Standalone native CLI — alpha

The original interpreter in `reflex/` is a Python reference implementation. A **standalone Rust CLI** now lives in [`native/`](native/), so ordinary Reflex core programs can run without Python installed:

```bash
cd native
cargo build --release -p reflex-cli
./target/release/reflex run ../examples/hello.rflx
```

The native alpha was compiled and verified against `examples/hello.rflx`. It currently targets the language core; the Python reference remains the broader web/desktop/bridge implementation while those capabilities move to Rust. GitHub Actions is configured to test native builds on Windows, macOS, and Linux.

For end users, the release path is intentionally simple: install one platform package, then run `reflex run hello.rflx`. See [INSTALL.md](INSTALL.md). Maintainer packaging sources live in [`installers/`](installers/).

## The short version

```rflx
# `let` is optional. A first assignment creates the value.
name = "Reflex"

greet(person) => `Hello, ${person}!`
print(greet(name))
```

```bash
python -m reflex examples/hello.rflx
python -m reflex examples/site.rflx
python -m reflex examples/desktop.rflx
```

The last command generates a native-desktop bundle in `examples/build/reflex-native`.

## Simpler syntax

Reflex keeps explicit declarations available, but does not require ceremony for ordinary code.

| Goal | Reflex |
|---|---|
| Make or update a variable | `score = 42` |
| Lock a value | `const api_name = "Reflex"` |
| One-line function | `double(n) => n * 2` |
| Block function | `greet(name):` then an indented body |
| Condition / loop | `if ready:` / `for item in items:` |
| Dynamic strings / HTML | `` `Hello, ${name}` `` |

```rflx
names = ["Ada", "Lin", "Maya"]

label(name):
    return `${name}!`

for name in names:
    print(label(name))
```

`let` and `fun` from the earlier, more explicit style still work. Prefer `const` when a binding must not change. Blocks use spaces and a trailing `:`. `#` and `//` start comments.

## Web: backend + frontend + middleware

One `.rflx` file can define routes, render HTML, return JSON, attach CSS, and add lightweight middleware.

```rflx
app = web()
headline = "One language. Every layer."

# Inline CSS
app.style("""
body { margin: 0; background: #0b1020; color: #f5f7ff; font-family: system-ui; }
.hero { max-width: 52rem; margin: 14vh auto; padding: 2rem; }
""")

# Or use a normal CSS file next to this .rflx source.
app.style_file("site.css")

audit(request):
    print(`${request.method} ${request.path}`)
app.use(audit)

home(request):
    return page("Reflex starter", `
        <main class="hero">
          <h1>${headline}</h1>
          <a href="/api/status">Check the API</a>
        </main>
    `)

status(request) => json({ ok: true, language: "Reflex" })

app.route("/", home)
app.route("/api/status", status)
app.start(3000)
```

### Web API

- `web()` — create an application
- `app.route(path, handler)` / `app.get(...)` / `app.post(...)` — register a route
- `app.use(handler)` — run middleware before matching a route. It can enrich `request` or return `json(...)` to stop early.
- `page(title, html)` — make a complete HTML document with every registered style
- `json(value, status = 200)` — make an API response
- `app.style(css)` / `app.style_file(path)` — use CSS from the `.rflx` file or an external `.css` file
- `app.export(folder)` — generate static HTML for registered routes
- `app.start(port = 3000)` — run the local GET/POST development server

The request object includes `path`, `method`, `query`, and (for POST) `body`.

## Native desktop apps

Reflex can package HTML and CSS into a native desktop target. The generated launcher uses [pywebview](https://pywebview.flowrl.com/), which hosts your HTML/CSS in a platform-native desktop window.

```rflx
# desktop.rflx
desktop = native("Reflex Notes")

desktop.style("""
body { margin: 0; padding: 2rem; background: #111827; color: white; font: 18px system-ui; }
.card { padding: 1.25rem; border-radius: 1rem; background: #1f2937; }
""")

desktop.html(`
  <main class="card">
    <h1>Reflex desktop</h1>
    <p>This window is native; its interface is HTML and CSS.</p>
  </main>
`)

desktop.window(960, 640)
desktop.build("build/reflex-notes")

# To launch directly instead of building files:
# desktop.start()
```

`desktop.build(folder)` writes:

- `index.html` — self-contained HTML and CSS
- `launcher.py` — a native WebView launcher

To run that launcher, install the optional host dependency once:

```bash
pip install pywebview
python build/reflex-notes/launcher.py
```

`desktop.html_file("screen.html")` and `desktop.style_file("theme.css")` let you keep markup and styling in separate files. This is currently a WebView-based desktop target; mobile, embedded, and fully compiled native backends are future work.

## Connect to Python, JavaScript, Lua, C++, C#, and more

Use `connect(language, target)` to call an external worker. A worker receives one JSON request on standard input and must print one JSON response. This is intentionally language-neutral: it works for interpreted languages, compiled binaries, and any process that can read/write JSON.

```rflx
math = connect("python", "bridges/python_math.py")
answer = math.call("add", 20, 22)
print(answer)  # 42
```

### Built-in bridge launchers

| Language name | What Reflex runs |
|---|---|
| `"python"`, `"py"` | the current Python interpreter plus the worker script |
| `"javascript"`, `"js"`, `"node"` | `node worker.js` |
| `"lua"` | `lua worker.lua` |
| `"ruby"`, `"php"`, `"r"` | that language runtime plus the worker |
| `"cpp"`, `"c++"`, `"c"`, `"native"` | a compiled executable directly |
| `"csharp"`, `"cs"`, `"dotnet"` | `dotnet worker.dll`, or a native executable |
| `"command"` | an explicit command line—for Java, Rust, Deno, Go, and other runtimes |

Example workers live in `examples/bridges/`. The needed external runtime/compiler remains your choice and must be installed locally.

### Bridge protocol

Reflex sends this JSON on stdin for `module.call("add", 2, 3)`:

```json
{"function":"add","args":[2,3]}
```

The worker prints either:

```json
{"result":5}
```

or:

```json
{"error":"human-readable explanation"}
```

A Python implementation:

```python
import json, sys
request = json.loads(sys.stdin.read())

if request["function"] == "add":
    print(json.dumps({"result": sum(request["args"])}))
else:
    print(json.dumps({"error": "unknown function"}))
```

> **Safety note:** a bridge deliberately executes a local program. Only connect to code and commands you trust, and do not expose arbitrary bridge targets to untrusted web input.

## What is implemented

- Indentation-based control flow and block functions
- Optional declarations, `const`, arrays, objects, functions, loops, `return`, `break`, `continue`
- JavaScript-friendly `true`, `false`, `null`, template strings, objects, and collection helpers
- Built-ins: `print`, `range`, `len`, `str`, `number`, `escape`, `read_text`, `json`
- Collection methods: `push`, `pop`, `map`, `filter`, `join`, `includes`, `upper`, `lower`, `trim`, and more
- Local HTTP backend, static HTML export, CSS inclusion, middleware, and native-WebView project generation
- JSON process bridges for Python, JavaScript, Lua, C/C++, C#, and extensible command-based runtimes

## Editor support

The repository includes a ready-to-package VS Code extension at `editors/vscode-reflex/`. It recognizes `.rflx`, highlights Reflex syntax, adds snippets, and provides **Reflex: Run Current File** / **Reflex: Check Current File** commands. Basic Sublime Text and Vim/Neovim definitions are also included.

```bash
cd editors/vscode-reflex
npm install
npm run package
code --install-extension reflex-language-support-0.1.0.vsix
```

See [`editors/README.md`](editors/README.md) for the supported editors and the Tree-sitter/LSP rollout path.

## Project layout

- `reflex/` — lexer, parser, tree-walking interpreter, HTTP runtime, native and bridge adapters
- `examples/` — executable `.rflx` programs, CSS, desktop, and foreign-language examples
- `editors/` — VS Code extension plus Sublime Text and Vim/Neovim syntax support
- `tests/` — regression suite

## Verify the prototype

```bash
python -m unittest discover -s tests -v
python -m reflex check examples/site.rflx
python -m reflex examples/hello.rflx
```

## Deliberate boundaries

This implementation favors a compact, understandable core over pretending to be a finished production platform. Before deploying public services or distributing desktop applications broadly, add a production HTTP host, permissions/sandboxing, async I/O, package resolution, source maps, robust process supervision, typed declarations, and platform installers.
