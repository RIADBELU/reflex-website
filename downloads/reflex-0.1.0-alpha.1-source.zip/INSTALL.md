# Install Reflex

## Normal user installation

Download the correct installer from the official Reflex Releases page. Install once, then use Reflex anywhere:

```bash
reflex run hello.rflx
```

No Python, Rust, Cargo, Node, or source checkout is needed for a published release.

| Your computer | Download | What to do |
|---|---|---|
| Windows 64-bit | `ReflexSetup-*-Windows-x64.exe` | Double-click it, keep **Add Reflex to PATH** checked, then click Install. |
| Mac with Intel processor | `ReflexSetup-*-macOS-x86_64.pkg` | Double-click it and follow the macOS Installer steps. |
| Mac with Apple Silicon | `ReflexSetup-*-macOS-arm64.pkg` | Double-click it and follow the macOS Installer steps. |
| Ubuntu/Debian Linux | `reflex_*_amd64.deb` | Double-click it in Software Install, or use your package manager. |

Open a new terminal after installing, then verify:

```bash
reflex --version
```

Create a file called `hello.rflx`:

```rflx
name = "World"
greet(person) => `Hello, ${person}!`
print(greet(name))
```

Run it:

```bash
reflex run hello.rflx
```

## Current alpha scope

The first native alpha is deliberately small. `reflex run` and `reflex check` work for the standalone language core. Web, desktop, external-language bridges, and package installation remain available only in the Python reference prototype until their Rust migrations are complete.

## Maintainers: make a release

1. Update the native Cargo version.
2. Ensure `cargo test --workspace` passes in `native/`.
3. Push a tag such as `v0.1.0-alpha.1`.
4. GitHub Actions produces Windows, macOS, and Linux release assets.
5. Test each package on a real device before announcing it.

Public Windows/macOS releases should be code-signed. See `installers/README.md`.
