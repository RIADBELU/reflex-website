# Reflex editor support

The editor assets in this directory make the `.rflx` extension recognizable and provide basic Reflex syntax highlighting.

| Editor | Current support | Install / development location |
|---|---|---|
| VS Code / VSCodium / Cursor | File association, TextMate highlighting, snippets, brackets, run/check commands | `vscode-reflex/` |
| Sublime Text | `.rflx` association and highlighting | `sublime/Reflex.sublime-syntax` |
| Vim / Neovim | `.rflx` filetype detection and highlighting | `vim/` |
| Zed, Helix, modern Neovim, GitHub-style tooling | Next step: Tree-sitter grammar and queries | planned |
| VS Code, JetBrains, Neovim, Emacs, Sublime, Kate | Next step: Language Server Protocol diagnostics/completion | planned |

## The support stack

1. **File association** teaches an editor that `*.rflx` means Reflex.
2. **TextMate/Sublime/Vim grammars** color code immediately and are fast to ship.
3. **Tree-sitter** supplies accurate incremental parsing, folding, structural selections, and advanced highlighting across modern editors.
4. **Language Server Protocol (LSP)** supplies completion, errors, hover help, go-to-definition, rename, and formatting to many editors from one implementation.

Start with the included VS Code extension. Build Tree-sitter and an LSP only after the core Reflex grammar is stable enough that editor behavior will not change every week.

## Install the included basic definitions

### Sublime Text

Copy `sublime/Reflex.sublime-syntax` into your User Packages folder:

- macOS: `~/Library/Application Support/Sublime Text/Packages/User/`
- Linux: `~/.config/sublime-text/Packages/User/`
- Windows: `%APPDATA%\\Sublime Text\\Packages\\User\\`

Restart Sublime Text, or select **View → Syntax → Reflex** for an open `.rflx` file.

### Vim and Neovim

For Vim:

```bash
cp -R vim/* ~/.vim/
```

For a classic Neovim configuration:

```bash
cp -R vim/* ~/.config/nvim/
```

Plugin managers can also install the `editors/vim` directory as a small Vim plugin.

## VS Code shortcut

Until the extension is installed, manually associate the extension in VS Code settings:

```json
{
  "files.associations": {
    "*.rflx": "reflex"
  }
}
```

That association becomes automatic after installing the packaged Reflex extension.

## Publishing order

1. Test the VS Code extension locally with **F5**.
2. Package a `.vsix` and install it locally.
3. Publish it to the Visual Studio Marketplace and Open VSX (for VSCodium and related editors).
4. Submit the Sublime package to Package Control.
5. Publish a Tree-sitter grammar.
6. Release the Reflex language server and integrate it with VS Code, Neovim, Helix, Zed, Emacs, and JetBrains.
