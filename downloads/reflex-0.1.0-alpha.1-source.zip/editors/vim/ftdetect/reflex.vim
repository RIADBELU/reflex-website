augroup filetypedetect
  autocmd! BufRead,BufNewFile *.rflx setfiletype reflex
augroup END
