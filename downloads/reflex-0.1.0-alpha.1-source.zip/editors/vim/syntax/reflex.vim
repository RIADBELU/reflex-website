" Basic Reflex syntax for Vim and Neovim.
if exists("b:current_syntax")
  finish
endif

syn keyword reflexStatement if elif else while for in return break continue let const fun
syn keyword reflexBoolean true false null True False None
syn keyword reflexBuiltin print len range str number escape json page web native connect read_text
syn match reflexFunction "^\s*\h\w*\ze\s*(.*)\s*\%(=>\|:\)"
syn match reflexNumber "\<\d\+\%(\.\d\+\)\?\>"
syn match reflexOperator "=>\|==\|!=\|<=\|>=\|&&\|||\|+=\|-=\|\*=\|/=\|[-+*/%=<>!]"
syn match reflexComment "#.*$"
syn match reflexComment "//.*$"
syn region reflexString start=+"+ skip=+\\"+ end=+"+
syn region reflexString start=+'+ skip=+\\'+ end=+'+
syn region reflexTemplate start=+`+ skip=+\\`+ end=+`+ contains=reflexInterpolation
syn region reflexInterpolation start=+${+ end=+}+ contained
syn region reflexTriple start=+"""+ end=+"""+ keepend

hi def link reflexStatement Statement
hi def link reflexBoolean Boolean
hi def link reflexBuiltin Function
hi def link reflexFunction Function
hi def link reflexNumber Number
hi def link reflexOperator Operator
hi def link reflexComment Comment
hi def link reflexString String
hi def link reflexTemplate String
hi def link reflexInterpolation Special
hi def link reflexTriple String

let b:current_syntax = "reflex"
