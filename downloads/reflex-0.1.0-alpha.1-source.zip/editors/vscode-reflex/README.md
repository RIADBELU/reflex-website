# Reflex Language Support for VS Code

This extension makes Visual Studio Code recognize `.rflx` files as **Reflex** and provides:

- Syntax highlighting for core Reflex syntax
- `.rflx` file association
- Comments, brackets, auto-closing pairs, and indentation rules
- Snippets for web apps, desktop apps, functions, loops, and foreign bridges
- **Reflex: Run Current File** and **Reflex: Check Current File** commands

## Try it during development

1. Open `editors/vscode-reflex` as a folder in VS Code.
2. Press **F5** to start an Extension Development Host.
3. Open any `.rflx` file in that new window.

For the run/check commands, set `reflex.executable` in VS Code settings to your CLI command. Once the native CLI exists, the default will be:

```json
{ "reflex.executable": "reflex" }
```

During this Python-prototype phase, an easy development wrapper is:

```bash
# macOS/Linux: create a script named reflex-dev somewhere on PATH
#!/usr/bin/env sh
exec python -m reflex "$@"
```

Then configure:

```json
{ "reflex.executable": "reflex-dev" }
```

## Package a VSIX

```bash
cd editors/vscode-reflex
npm install
npm run package
```

This produces a `.vsix` file. Install it locally with:

```bash
code --install-extension reflex-language-support-0.1.0.vsix
```

## Publish publicly

1. Create a publisher account in the [Visual Studio Marketplace](https://marketplace.visualstudio.com/manage).
2. Reserve the `reflex-lang` publisher ID, or change `publisher` in `package.json` to your own ID.
3. Create an Azure DevOps personal access token with Marketplace publishing permission.
4. Run `npx @vscode/vsce login YOUR_PUBLISHER`.
5. Run `npm run publish`.

Use a distinct publisher namespace and confirm the Reflex project name is legally available before publishing.
