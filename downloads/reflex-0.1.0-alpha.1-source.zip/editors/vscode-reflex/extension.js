// Minimal, dependency-free VS Code integration. It becomes fully standalone
// once the native `reflex` CLI is distributed; for now configure the executable
// setting to point at your development runner if desired.
const vscode = require("vscode");
const { execFile } = require("child_process");

function activeReflexFile() {
  const editor = vscode.window.activeTextEditor;
  if (!editor || editor.document.languageId !== "reflex") {
    vscode.window.showErrorMessage("Open a .rflx Reflex file first.");
    return undefined;
  }
  if (editor.document.isDirty) {
    editor.document.save();
  }
  return editor.document.uri.fsPath;
}

function run(command, args, output) {
  output.show(true);
  output.appendLine(`$ ${command} ${args.map(part => JSON.stringify(part)).join(" ")}`);
  const child = execFile(command, args, { cwd: vscode.workspace.workspaceFolders?.[0]?.uri.fsPath });
  child.stdout.on("data", data => output.append(data.toString()));
  child.stderr.on("data", data => output.append(data.toString()));
  child.on("error", error => output.appendLine(`Unable to start Reflex: ${error.message}`));
  child.on("close", code => output.appendLine(`\nReflex exited with code ${code}.`));
}

function activate(context) {
  const output = vscode.window.createOutputChannel("Reflex");
  const executable = () => vscode.workspace.getConfiguration("reflex").get("executable", "reflex");

  context.subscriptions.push(
    output,
    vscode.commands.registerCommand("reflex.runFile", () => {
      const file = activeReflexFile();
      if (file) run(executable(), ["run", file], output);
    }),
    vscode.commands.registerCommand("reflex.checkFile", () => {
      const file = activeReflexFile();
      if (file) run(executable(), ["check", file], output);
    })
  );
}

function deactivate() {}

module.exports = { activate, deactivate };
