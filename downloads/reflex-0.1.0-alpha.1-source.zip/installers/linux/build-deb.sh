#!/usr/bin/env bash
# Build a standard Debian package. On Ubuntu/Debian, a user can double-click
# the resulting .deb in the Software Install GUI or install it from a terminal.
set -euo pipefail

VERSION="${VERSION:?Set VERSION, for example 0.1.0-alpha.1}"
REFLEX_BIN="${REFLEX_BIN:?Set REFLEX_BIN to the compiled reflex binary}"
ARCH="${ARCH:-amd64}"
ROOT="${ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
OUTPUT="$ROOT/dist"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

mkdir -p "$STAGE/DEBIAN" "$STAGE/usr/bin" "$OUTPUT"
install -m 0755 "$REFLEX_BIN" "$STAGE/usr/bin/reflex"
cat > "$STAGE/DEBIAN/control" <<EOF
Package: reflex
Version: $VERSION
Section: devel
Priority: optional
Architecture: $ARCH
Maintainer: Reflex contributors <maintainers@reflex.invalid>
Description: Reflex programming language CLI
 Standalone command-line runtime for Reflex .rflx programs.
EOF

dpkg-deb --build --root-owner-group "$STAGE" "$OUTPUT/reflex_${VERSION}_${ARCH}.deb"
echo "Created $OUTPUT/reflex_${VERSION}_${ARCH}.deb"
