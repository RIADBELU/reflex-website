; Reflex Setup for Windows
; Build on Windows with Inno Setup 6:
;   ISCC.exe /DMyAppVersion=0.1.0-alpha.1 /DBuildDir=..\..\native\target\release ReflexSetup.iss

#ifndef MyAppVersion
  #define MyAppVersion "0.1.0-alpha.1"
#endif
#ifndef BuildDir
  #define BuildDir "..\..\native\target\release"
#endif

#define MyAppName "Reflex"
#define MyAppPublisher "Reflex contributors"
#define MyAppURL "https://github.com/reflex-lang/reflex"
#define MyAppExeName "reflex.exe"

[Setup]
AppId={{F7DAB4A7-3B45-4A1E-A0C6-5A29FD94B5A3}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}/releases
DefaultDirName={localappdata}\Programs\Reflex
DefaultGroupName=Reflex
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=..\..\dist
OutputBaseFilename=ReflexSetup-{#MyAppVersion}-Windows-x64
SetupIconFile=reflex.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
ChangesEnvironment=yes

[Tasks]
Name: "addpath"; Description: "Add Reflex to your user PATH (recommended)"; GroupDescription: "Command-line options:"; Flags: checked
Name: "vscode"; Description: "Open VS Code extension instructions after setup"; Flags: unchecked

[Files]
Source: "{#BuildDir}\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\..\README.md"; DestDir: "{app}\docs"; DestName: "README.md"; Flags: ignoreversion
Source: "..\..\editors\vscode-reflex\reflex-language-support-0.1.0.vsix"; DestDir: "{app}\vscode"; Flags: ignoreversion skipifsourcedoesntexist

[Icons]
Name: "{autoprograms}\Reflex\Reflex Command Prompt"; Filename: "{cmd}"; Parameters: "/K \"\"{app}\{#MyAppExeName}\" --help\""; WorkingDir: "{userprofile}"
Name: "{autoprograms}\Reflex\Uninstall Reflex"; Filename: "{uninstallexe}"

[Registry]
; Per-user .rflx association. Opening a file checks it; no association is forced.
Root: HKCU; Subkey: "Software\Classes\.rflx"; ValueType: string; ValueName: ""; ValueData: "Reflex.File"; Flags: uninsdeletevalue
Root: HKCU; Subkey: "Software\Classes\Reflex.File"; ValueType: string; ValueName: ""; ValueData: "Reflex source file"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Classes\Reflex.File\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\{#MyAppExeName},0"
Root: HKCU; Subkey: "Software\Classes\Reflex.File\shell\open\command"; ValueType: string; ValueName: ""; ValueData: "\"{app}\{#MyAppExeName}\" run \"%1\""

[Code]
const
  UserPathKey = 'Environment';

procedure AddReflexToPath();
var
  PathValue: String;
begin
  if not RegQueryStringValue(HKCU, UserPathKey, 'Path', PathValue) then
    PathValue := '';
  if Pos(ExpandConstant('{app}'), PathValue) = 0 then begin
    if (PathValue <> '') and (PathValue[Length(PathValue)] <> ';') then
      PathValue := PathValue + ';';
    RegWriteStringValue(HKCU, UserPathKey, 'Path', PathValue + ExpandConstant('{app}'));
  end;
end;

procedure RemoveReflexFromPath();
var
  PathValue, AppPath: String;
begin
  AppPath := ExpandConstant('{app}');
  if RegQueryStringValue(HKCU, UserPathKey, 'Path', PathValue) then begin
    StringChangeEx(PathValue, ';' + AppPath, '', True);
    StringChangeEx(PathValue, AppPath + ';', '', True);
    StringChangeEx(PathValue, AppPath, '', True);
    RegWriteStringValue(HKCU, UserPathKey, 'Path', PathValue);
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if (CurStep = ssPostInstall) and WizardIsTaskSelected('addpath') then
    AddReflexToPath();
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
    RemoveReflexFromPath();
end;

procedure CurPageChanged(CurPageID: Integer);
begin
  if (CurPageID = wpFinished) and WizardIsTaskSelected('vscode') then
    MsgBox('Install the bundled VS Code extension from:' + #13#10 + ExpandConstant('{app}\vscode\reflex-language-support-0.1.0.vsix'), mbInformation, MB_OK);
end;
