#!/usr/bin/env bash
# Build a macOS Installer.app-compatible package. The package itself provides
# the normal macOS graphical installation wizard when a user double-clicks it.
set -euo pipefail

VERSION="${VERSION:?Set VERSION, for example 0.1.0-alpha.1}"
REFLEX_BIN="${REFLEX_BIN:?Set REFLEX_BIN to the compiled reflex binary}"
ARCH="${ARCH:-$(uname -m)}"
ROOT="${ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
OUTPUT="$ROOT/dist"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

mkdir -p "$STAGE/usr/local/bin" "$OUTPUT"
install -m 0755 "$REFLEX_BIN" "$STAGE/usr/local/bin/reflex"

# A public release should sign the executable before packaging it. Local and
# early alpha packages can leave this unset and remain usable for testing.
if [[ -n "${MACOS_APPLICATION_IDENTITY:-}" ]]; then
  codesign --force --options runtime --timestamp --sign "$MACOS_APPLICATION_IDENTITY" "$STAGE/usr/local/bin/reflex"
fi

PKG="$OUTPUT/ReflexSetup-$VERSION-macOS-$ARCH.pkg"
PKGBUILD_ARGS=(--root "$STAGE" --identifier dev.reflex-lang.reflex --version "$VERSION" --install-location /)
if [[ -n "${MACOS_INSTALLER_IDENTITY:-}" ]]; then
  PKGBUILD_ARGS+=(--sign "$MACOS_INSTALLER_IDENTITY")
fi
pkgbuild "${PKGBUILD_ARGS[@]}" "$PKG"

# Optional notarization for public releases. Configure a named notarytool
# profile in the Apple keychain; never commit Apple credentials to the repo.
if [[ -n "${MACOS_NOTARY_PROFILE:-}" ]]; then
  xcrun notarytool submit "$PKG" --keychain-profile "$MACOS_NOTARY_PROFILE" --wait
  xcrun stapler staple "$PKG"
fi

echo "Created $PKG"
