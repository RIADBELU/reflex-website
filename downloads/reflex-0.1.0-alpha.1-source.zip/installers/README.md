# Reflex installers

These are the release packaging sources for the standalone native `reflex` executable. End users should install a platform package once, then run:

```bash
reflex run hello.rflx
```

They should never need Python, Cargo, or the Reflex source repository.

## Windows — graphical setup wizard

`windows/ReflexSetup.iss` is an Inno Setup 6 installer with a native GUI. It:

- installs Reflex per user without requiring administrator rights
- offers a checked **Add Reflex to PATH** option
- associates `.rflx` with Reflex
- includes an uninstaller
- optionally carries the VS Code `.vsix` package

Build it on Windows after compiling `native/target/release/reflex.exe`:

```powershell
& "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" `
  /DMyAppVersion=0.1.0-alpha.1 `
  /DBuildDir="..\..\native\target\release" `
  installers\windows\ReflexSetup.iss
```

## macOS — graphical Installer package

A `.pkg` opens Apple’s normal graphical Installer app. Build it on macOS:

```bash
VERSION=0.1.0-alpha.1 \
REFLEX_BIN="$PWD/native/target/release/reflex" \
installers/macos/build-pkg.sh
```

For public macOS distribution, set `MACOS_APPLICATION_IDENTITY`, `MACOS_INSTALLER_IDENTITY`, and `MACOS_NOTARY_PROFILE` in secure CI secrets to sign the executable, sign the package, and notarize it.

### Build it without owning a Mac

After putting the project in GitHub, open **Actions → Build macOS Reflex Installer → Run workflow**, enter the version, and download the two artifacts when it finishes:

```text
ReflexSetup-VERSION-macOS-x86_64.pkg  # Intel Macs
ReflexSetup-VERSION-macOS-arm64.pkg   # Apple Silicon Macs
```

That workflow runs `pkgbuild` on real macOS runners and tests the native CLI before packaging.

## Linux — package-manager GUI installation

Linux has no universal installer format. The script creates a standard `.deb`; Ubuntu/Debian users can double-click it in their graphical software installer. Build it on a Debian-family Linux runner:

```bash
VERSION=0.1.0-alpha.1 \
REFLEX_BIN="$PWD/native/target/release/reflex" \
installers/linux/build-deb.sh
```

A production release should also provide RPM and AppImage artifacts. The CLI itself remains a single native binary on every platform.

## Security and release rule

The installer source may be public. Certificates, private keys, Apple credentials, and publishing tokens must **never** be put in this repository or supplied in chat. Store them as encrypted CI secrets.
