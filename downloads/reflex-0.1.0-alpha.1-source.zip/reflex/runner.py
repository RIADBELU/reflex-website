"""Public helpers for running `.rflx` programs from Python."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from .lexer import Lexer
from .parser import Parser
from .runtime import Evaluator


def parse_source(source: str, filename: str = "<memory>"):
    return Parser(Lexer(source, filename).tokenize()).parse()


def run_source(source: str, filename: str = "<memory>", source_dir: str | Path = ".") -> tuple[Evaluator, Any]:
    program = parse_source(source, filename)
    evaluator = Evaluator(source_dir)
    return evaluator, evaluator.execute(program)


def run_file(path: str | Path) -> tuple[Evaluator, Any]:
    file = Path(path)
    source = file.read_text(encoding="utf-8")
    return run_source(source, str(file), file.parent)
