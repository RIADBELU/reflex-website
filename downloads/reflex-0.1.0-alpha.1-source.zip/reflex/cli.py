"""Command-line entry point for Reflex."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

from .lexer import Lexer, ReflexSyntaxError
from .runner import parse_source, run_file
from .runtime import ReflexRuntimeError


def main(argv: list[str] | None = None) -> int:
    # Make `reflex app.rflx` the pleasant default while retaining subcommands.
    arguments = list(sys.argv[1:] if argv is None else argv)
    commands = {"run", "check", "tokens"}
    if arguments and arguments[0] not in commands and not arguments[0].startswith("-"):
        arguments.insert(0, "run")
    parser = argparse.ArgumentParser(prog="reflex", description="Run Reflex (.rflx) programs")
    parser.add_argument("command", nargs="?", default="run", choices=tuple(commands), help="run (default), check, or tokens")
    parser.add_argument("file", nargs="?", help="Reflex source file")
    args = parser.parse_args(arguments)
    if not args.file:
        parser.error("a .rflx file is required")

    source_file = Path(args.file)
    if source_file.suffix != ".rflx":
        print("warning: Reflex files conventionally use the .rflx extension", file=sys.stderr)
    try:
        source = source_file.read_text(encoding="utf-8")
        if args.command == "tokens":
            for token in Lexer(source, str(source_file)).tokenize():
                print(f"{token.line:>3}:{token.column:<3} {token.kind:<14} {token.value!r}")
            return 0
        if args.command == "check":
            parse_source(source, str(source_file))
            print(f"✓ {source_file}: syntax is valid Reflex")
            return 0
        run_file(source_file)
        return 0
    except (OSError, ReflexSyntaxError, ReflexRuntimeError) as error:
        print(f"Reflex error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
