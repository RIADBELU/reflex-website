"""Tree-walking evaluator and tiny standard library for Reflex."""
from __future__ import annotations

from dataclasses import dataclass
from html import escape as html_escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json as json_module
from pathlib import Path
import re
import shlex
import subprocess
import sys
from typing import Any, Callable
from urllib.parse import parse_qs, urlparse

from . import parser as ast
from .lexer import Lexer, ReflexSyntaxError
from .parser import Parser


class ReflexRuntimeError(Exception):
    pass


@dataclass
class Binding:
    value: Any
    constant: bool = False


class Environment:
    def __init__(self, parent: "Environment | None" = None):
        self.parent = parent
        self.values: dict[str, Binding] = {}

    def define(self, name: str, value: Any, constant: bool = False) -> None:
        if name in self.values:
            raise ReflexRuntimeError(f"'{name}' is already declared in this scope")
        self.values[name] = Binding(value, constant)

    def get(self, name: str) -> Any:
        if name in self.values:
            return self.values[name].value
        if self.parent is not None:
            return self.parent.get(name)
        raise ReflexRuntimeError(f"unknown name '{name}'")

    def contains(self, name: str) -> bool:
        return name in self.values or (self.parent is not None and self.parent.contains(name))

    def assign(self, name: str, value: Any) -> Any:
        if name in self.values:
            binding = self.values[name]
            if binding.constant:
                raise ReflexRuntimeError(f"cannot reassign const '{name}'")
            binding.value = value
            return value
        if self.parent is not None:
            return self.parent.assign(name, value)
        raise ReflexRuntimeError(f"cannot assign undeclared name '{name}'")


class _Return(Exception):
    def __init__(self, value: Any): self.value = value
class _Break(Exception): pass
class _Continue(Exception): pass


@dataclass
class Function:
    params: list[tuple[str, Any]]
    body: Any
    closure: Environment
    expression_body: bool
    evaluator: "Evaluator"
    name: str = "<function>"

    def __call__(self, *args: Any) -> Any:
        if len(args) > len(self.params):
            raise ReflexRuntimeError(f"{self.name} expected at most {len(self.params)} argument(s), got {len(args)}")
        local = Environment(self.closure)
        for index, (name, default) in enumerate(self.params):
            if index < len(args):
                local.define(name, args[index])
            elif default is not None:
                local.define(name, self.evaluator.evaluate(default, local))
            else:
                raise ReflexRuntimeError(f"{self.name} is missing required argument '{name}'")
        try:
            if self.expression_body:
                return self.evaluator.evaluate(self.body, local)
            self.evaluator.execute_block(self.body, local)
        except _Return as result:
            return result.value
        return None


@dataclass
class Response:
    body: str
    content_type: str = "text/html; charset=utf-8"
    status: int = 200
    headers: dict[str, str] | None = None


class ForeignModule:
    """One-call JSON bridge for programs written in another language.

    Each foreign worker reads one JSON object from stdin and prints a JSON result
    to stdout. This deliberately keeps a bridge portable across scripting,
    native, and compiled languages without embedding their runtimes in Reflex.
    """
    RUNTIME_ALIASES = {
        "python": None, "py": None,
        "javascript": "node", "js": "node", "node": "node",
        "lua": "lua", "ruby": "ruby", "php": "php", "r": "Rscript",
    }

    def __init__(self, source_dir: Path, language: Any, target: Any, timeout: Any = 10):
        self.source_dir = source_dir
        self.language = str(language).lower()
        self.target = str(target)
        try:
            self.timeout = float(timeout)
        except (TypeError, ValueError) as error:
            raise ReflexRuntimeError("connect timeout must be a number of seconds") from error

    def _target_path(self) -> str:
        file = Path(self.target)
        return str(file if file.is_absolute() else (self.source_dir / file).resolve())

    def _command(self) -> list[str]:
        target = self._target_path()
        if self.language in {"python", "py"}:
            return [sys.executable, target]
        if self.language in {"javascript", "js", "node"}:
            return ["node", target]
        if self.language in {"lua", "ruby", "php", "r"}:
            return [self.RUNTIME_ALIASES[self.language], target]
        if self.language in {"csharp", "cs", "dotnet"}:
            return ["dotnet", target] if target.lower().endswith(".dll") else [target]
        if self.language in {"cpp", "c++", "c", "native", "executable", "exec"}:
            return [target]
        if self.language in {"command", "shell"}:
            # Explicit command mode is intentionally opt-in. It is useful for
            # any runtime not named above (for example Deno, Java, or Rust).
            return shlex.split(self.target)
        raise ReflexRuntimeError(
            f"unsupported bridge language '{self.language}'. Use command for a custom runtime."
        )

    def call(self, function: Any, *args: Any) -> Any:
        request = {"function": str(function), "args": list(args)}
        try:
            payload = json_module.dumps(request, ensure_ascii=False)
        except TypeError as error:
            raise ReflexRuntimeError(f"foreign call arguments must be JSON values: {error}") from error
        try:
            process = subprocess.run(
                self._command(), input=payload + "\n", text=True, capture_output=True,
                timeout=self.timeout, cwd=self.source_dir, check=False,
            )
        except FileNotFoundError as error:
            raise ReflexRuntimeError(f"bridge runtime or target was not found: {error.filename}") from error
        except subprocess.TimeoutExpired as error:
            raise ReflexRuntimeError(f"foreign call timed out after {self.timeout:g} seconds") from error
        if process.returncode != 0:
            detail = process.stderr.strip() or process.stdout.strip() or f"exit status {process.returncode}"
            raise ReflexRuntimeError(f"{self.language} bridge failed: {detail}")
        lines = [line for line in process.stdout.splitlines() if line.strip()]
        if not lines:
            raise ReflexRuntimeError(f"{self.language} bridge returned no JSON result")
        try:
            result = json_module.loads(lines[-1])
        except json_module.JSONDecodeError as error:
            raise ReflexRuntimeError(f"{self.language} bridge must end with a JSON result: {error}") from error
        if isinstance(result, dict) and "error" in result:
            raise ReflexRuntimeError(f"{self.language} bridge error: {result['error']}")
        return result.get("result") if isinstance(result, dict) and "result" in result else result


class NativeApp:
    """Desktop target powered by the optional, cross-platform pywebview host."""
    def __init__(self, evaluator: "Evaluator", title: Any = "Reflex app"):
        self.evaluator = evaluator
        self.source_dir = evaluator.source_dir
        self.title = str(title)
        self.styles: list[str] = []
        self.markup = "<main></main>"
        self.width, self.height = 960, 640

    def style(self, css: Any) -> "NativeApp":
        self.styles.append(str(css))
        return self

    def style_file(self, path: Any) -> "NativeApp":
        target = (self.source_dir / str(path)).resolve()
        try:
            self.styles.append(target.read_text(encoding="utf-8"))
        except OSError as error:
            raise ReflexRuntimeError(f"could not read CSS file {path!r}: {error}") from error
        return self

    def html(self, markup: Any) -> "NativeApp":
        self.markup = str(markup)
        return self

    content = html

    def html_file(self, path: Any) -> "NativeApp":
        target = (self.source_dir / str(path)).resolve()
        try:
            self.markup = target.read_text(encoding="utf-8")
        except OSError as error:
            raise ReflexRuntimeError(f"could not read HTML file {path!r}: {error}") from error
        return self

    def window(self, width: Any = 960, height: Any = 640) -> "NativeApp":
        try:
            self.width, self.height = int(width), int(height)
        except (TypeError, ValueError) as error:
            raise ReflexRuntimeError("window(width, height) needs numeric dimensions") from error
        if self.width < 200 or self.height < 200:
            raise ReflexRuntimeError("native windows must be at least 200 × 200")
        return self

    def render(self) -> str:
        return (
            "<!doctype html><html><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
            f"<title>{html_escape(self.title)}</title><style>{chr(10).join(self.styles)}</style>"
            f"</head><body>{self.markup}</body></html>"
        )

    def build(self, folder: Any = "build/native") -> "NativeApp":
        output = (self.source_dir / str(folder)).resolve()
        output.mkdir(parents=True, exist_ok=True)
        (output / "index.html").write_text(self.render(), encoding="utf-8")
        launcher = f'''# Generated by Reflex. Install pywebview, then run this file.\nimport pathlib\nimport webview\n\npage = pathlib.Path(__file__).with_name("index.html").resolve().as_uri()\nwebview.create_window({self.title!r}, page, width={self.width}, height={self.height})\nwebview.start()\n'''
        (output / "launcher.py").write_text(launcher, encoding="utf-8")
        print(f"Built native Reflex app in {output}")
        return self

    export = build

    def start(self) -> None:
        try:
            import webview  # type: ignore[import-not-found]
        except ImportError as error:
            raise ReflexRuntimeError(
                "native apps use pywebview. Install it with `pip install pywebview`, or call desktop.build() to generate the host files."
            ) from error
        webview.create_window(self.title, html=self.render(), width=self.width, height=self.height)
        webview.start()


class WebApp:
    """Small local-development HTTP adapter exposed by web()."""
    def __init__(self, evaluator: "Evaluator", source_dir: Path):
        self.evaluator = evaluator
        self.source_dir = source_dir
        self.routes: dict[str, Callable[..., Any]] = {}
        self.middlewares: list[Callable[..., Any]] = []
        self.styles: list[str] = []

    def style(self, css: Any) -> "WebApp":
        self.styles.append(str(css))
        return self

    def style_file(self, path: Any) -> "WebApp":
        target = (self.source_dir / str(path)).resolve()
        try:
            self.styles.append(target.read_text(encoding="utf-8"))
        except OSError as error:
            raise ReflexRuntimeError(f"could not read CSS file {path!r}: {error}") from error
        return self

    def route(self, path: Any, handler: Any) -> "WebApp":
        path = str(path)
        if not path.startswith("/"):
            raise ReflexRuntimeError("route paths must begin with '/'")
        if not callable(handler):
            raise ReflexRuntimeError("route handler must be a function")
        self.routes[path] = handler
        return self

    get = route
    post = route

    def use(self, middleware: Any) -> "WebApp":
        """Register a small middleware hook: fun(request) => null or a Response."""
        if not callable(middleware):
            raise ReflexRuntimeError("middleware must be a function")
        self.middlewares.append(middleware)
        return self

    def _call_route(self, path: str, request: dict[str, Any]) -> Response:
        for middleware in self.middlewares:
            result = self.evaluator.call_value(middleware, [request])
            if isinstance(result, Response):
                return result
        handler = self.routes.get(path)
        if handler is None:
            return Response("<h1>404 — Not found</h1>", status=404)
        result = self.evaluator.call_value(handler, [request])
        if isinstance(result, Response):
            return result
        return Response(stringify(result))

    def start(self, port: Any = 3000) -> None:
        try:
            port = int(port)
        except (TypeError, ValueError) as error:
            raise ReflexRuntimeError("app.start(port) needs a numeric port") from error
        app = self

        class Handler(BaseHTTPRequestHandler):
            def handle_reflex_request(self) -> None:
                parsed = urlparse(self.path)
                content_length = int(self.headers.get("Content-Length", "0"))
                body = self.rfile.read(content_length).decode("utf-8") if content_length else ""
                request = {
                    "path": parsed.path,
                    "query": {k: v[-1] if len(v) == 1 else v for k, v in parse_qs(parsed.query).items()},
                    "method": self.command,
                    "body": body,
                }
                try:
                    response = app._call_route(parsed.path, request)
                except Exception as error:  # local dev server should show useful feedback
                    response = Response(f"<h1>Reflex runtime error</h1><pre>{html_escape(str(error))}</pre>", status=500)
                payload = response.body.encode("utf-8")
                self.send_response(response.status)
                self.send_header("Content-Type", response.content_type)
                for key, value in (response.headers or {}).items():
                    self.send_header(key, value)
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def do_GET(self) -> None:  # noqa: N802 (HTTP API spelling)
                self.handle_reflex_request()

            def do_POST(self) -> None:  # noqa: N802 (HTTP API spelling)
                self.handle_reflex_request()

            def log_message(self, format: str, *args: Any) -> None:
                print("[Reflex] " + (format % args))

        server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
        print(f"Reflex app running at http://localhost:{port}  (Ctrl+C to stop)")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nReflex app stopped.")
        finally:
            server.server_close()

    def export(self, folder: Any = "dist") -> "WebApp":
        output = (self.source_dir / str(folder)).resolve()
        output.mkdir(parents=True, exist_ok=True)
        for route in self.routes:
            if "{" in route or "}" in route:
                continue
            response = self._call_route(route, {"path": route, "query": {}, "method": "BUILD"})
            rel = route.strip("/")
            destination = output / rel / "index.html" if rel else output / "index.html"
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(response.body, encoding="utf-8")
        print(f"Exported {len(self.routes)} route(s) to {output}")
        return self


class Evaluator:
    def __init__(self, source_dir: str | Path = "."):
        self.source_dir = Path(source_dir).resolve()
        self.current_app: WebApp | None = None
        self.globals = Environment()
        self._install_builtins()

    def _install_builtins(self) -> None:
        def output(*items: Any) -> None:
            print(*[stringify(item) for item in items])

        self.globals.define("print", output, constant=True)
        self.globals.define("len", lambda item: len(item), constant=True)
        self.globals.define("range", self._range, constant=True)
        self.globals.define("str", stringify, constant=True)
        self.globals.define("number", self._number, constant=True)
        self.globals.define("escape", lambda value: html_escape(stringify(value)), constant=True)
        self.globals.define("json", self._json_response, constant=True)
        self.globals.define("page", self._page, constant=True)
        self.globals.define("web", self._web, constant=True)
        self.globals.define("native", self._native, constant=True)
        self.globals.define("connect", self._connect, constant=True)
        self.globals.define("read_text", self._read_text, constant=True)

    def _range(self, start: Any, end: Any | None = None, step: Any = 1) -> list[int]:
        if end is None:
            start, end = 0, start
        try:
            return list(range(int(start), int(end), int(step)))
        except ValueError as error:
            raise ReflexRuntimeError("range step cannot be zero") from error

    def _number(self, value: Any) -> int | float:
        try:
            number = float(value)
            return int(number) if number.is_integer() else number
        except (TypeError, ValueError) as error:
            raise ReflexRuntimeError(f"cannot convert {value!r} to a number") from error

    def _web(self) -> WebApp:
        app = WebApp(self, self.source_dir)
        self.current_app = app
        return app

    def _native(self, title: Any = "Reflex app") -> NativeApp:
        return NativeApp(self, title)

    def _connect(self, language: Any, target: Any, timeout: Any = 10) -> ForeignModule:
        return ForeignModule(self.source_dir, language, target, timeout)

    def _read_text(self, path: Any) -> str:
        target = (self.source_dir / str(path)).resolve()
        try:
            return target.read_text(encoding="utf-8")
        except OSError as error:
            raise ReflexRuntimeError(f"could not read file {path!r}: {error}") from error

    def _page(self, title: Any, body: Any, language: Any = "en") -> str:
        css = "\n".join(self.current_app.styles) if self.current_app else ""
        return "<!doctype html>\n" + (
            f'<html lang="{html_escape(stringify(language), quote=True)}"><head>'
            '<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            f"<title>{html_escape(stringify(title))}</title><style>{css}</style></head><body>{stringify(body)}</body></html>"
        )

    def _json_response(self, value: Any, status: Any = 200) -> Response:
        try:
            body = json_module.dumps(value, ensure_ascii=False, separators=(",", ":"))
        except TypeError as error:
            raise ReflexRuntimeError(f"json() could not encode value: {error}") from error
        return Response(body, "application/json; charset=utf-8", int(status))

    def execute(self, program: ast.Program, environment: Environment | None = None) -> Any:
        env = environment or self.globals
        result = None
        for statement in program.statements:
            result = self.execute_statement(statement, env)
        return result

    def execute_block(self, statements: list[Any], environment: Environment) -> Any:
        result = None
        for statement in statements:
            result = self.execute_statement(statement, environment)
        return result

    def execute_statement(self, node: Any, env: Environment) -> Any:
        if isinstance(node, ast.VarDecl):
            value = self.evaluate(node.value, env)
            env.define(node.name, value, node.constant)
            return value
        if isinstance(node, ast.FunctionDecl):
            function = Function(node.params, node.body, env, node.expression_body, self, node.name)
            env.define(node.name, function, constant=True)
            return function
        if isinstance(node, ast.Return):
            raise _Return(None if node.value is None else self.evaluate(node.value, env))
        if isinstance(node, ast.ExprStmt):
            return self.evaluate(node.expression, env)
        if isinstance(node, ast.Assignment):
            value = self.evaluate(node.value, env)
            return self.assign(node.target, node.operator, value, env)
        if isinstance(node, ast.If):
            for condition, body in node.branches:
                if truthy(self.evaluate(condition, env)):
                    return self.execute_block(body, Environment(env))
            if node.otherwise is not None:
                return self.execute_block(node.otherwise, Environment(env))
            return None
        if isinstance(node, ast.While):
            result = None
            while truthy(self.evaluate(node.condition, env)):
                try:
                    result = self.execute_block(node.body, Environment(env))
                except _Break:
                    break
                except _Continue:
                    continue
            return result
        if isinstance(node, ast.For):
            values = self.evaluate(node.iterable, env)
            if values is None:
                raise ReflexRuntimeError("cannot loop over null")
            result = None
            for value in values:
                local = Environment(env)
                local.define(node.name, value)
                try:
                    result = self.execute_block(node.body, local)
                except _Break:
                    break
                except _Continue:
                    continue
            return result
        if isinstance(node, ast.Break):
            raise _Break()
        if isinstance(node, ast.Continue):
            raise _Continue()
        raise ReflexRuntimeError(f"cannot execute node {type(node).__name__}")

    def evaluate(self, node: Any, env: Environment) -> Any:
        if isinstance(node, ast.Literal): return node.value
        if isinstance(node, ast.Template): return self.interpolate(node.text, env)
        if isinstance(node, ast.Identifier): return env.get(node.name)
        if isinstance(node, ast.ListExpr): return [self.evaluate(value, env) for value in node.values]
        if isinstance(node, ast.ObjectExpr): return {key: self.evaluate(value, env) for key, value in node.pairs}
        if isinstance(node, ast.FunctionExpr): return Function(node.params, node.body, env, node.expression_body, self)
        if isinstance(node, ast.Unary):
            value = self.evaluate(node.right, env)
            if node.operator == "NOT": return not truthy(value)
            if node.operator == "MINUS": return -value
            if node.operator == "PLUS": return +value
        if isinstance(node, ast.Binary): return self.binary(node, env)
        if isinstance(node, ast.Call):
            return self.call_value(self.evaluate(node.callee, env), [self.evaluate(arg, env) for arg in node.args])
        if isinstance(node, ast.Member): return self.get_member(self.evaluate(node.object, env), node.name)
        if isinstance(node, ast.Index):
            obj, index = self.evaluate(node.object, env), self.evaluate(node.index, env)
            try: return obj[index]
            except (KeyError, IndexError, TypeError) as error: raise ReflexRuntimeError(f"cannot index value: {error}") from error
        raise ReflexRuntimeError(f"cannot evaluate node {type(node).__name__}")

    def binary(self, node: ast.Binary, env: Environment) -> Any:
        left = self.evaluate(node.left, env)
        if node.operator == "AND": return self.evaluate(node.right, env) if truthy(left) else left
        if node.operator == "OR": return left if truthy(left) else self.evaluate(node.right, env)
        right = self.evaluate(node.right, env)
        try:
            if node.operator == "PLUS":
                return stringify(left) + stringify(right) if isinstance(left, str) or isinstance(right, str) else left + right
            if node.operator == "MINUS": return left - right
            if node.operator == "STAR": return left * right
            if node.operator == "SLASH": return left / right
            if node.operator == "PERCENT": return left % right
            if node.operator == "EQ": return left == right
            if node.operator == "NE": return left != right
            if node.operator == "LT": return left < right
            if node.operator == "LE": return left <= right
            if node.operator == "GT": return left > right
            if node.operator == "GE": return left >= right
            if node.operator == "IN": return left in right
        except (TypeError, ValueError, ZeroDivisionError) as error:
            raise ReflexRuntimeError(f"invalid {node.operator} operation: {error}") from error
        raise ReflexRuntimeError(f"unknown binary operator {node.operator}")

    def assign(self, target: Any, operator: str, value: Any, env: Environment) -> Any:
        if operator != "ASSIGN":
            operator_map = {"PLUS_ASSIGN": "PLUS", "MINUS_ASSIGN": "MINUS", "STAR_ASSIGN": "STAR", "SLASH_ASSIGN": "SLASH"}
            current = self.evaluate(target, env)
            value = self.binary(ast.Binary(ast.Literal(current), operator_map[operator], ast.Literal(value)), env)
        if isinstance(target, ast.Identifier):
            # Declaration-free assignment is the easy default in Reflex. `let`
            # remains available for readers who prefer explicit declarations and
            # `const` retains immutable bindings.
            if operator == "ASSIGN" and not env.contains(target.name):
                env.define(target.name, value)
                return value
            return env.assign(target.name, value)
        if isinstance(target, ast.Member):
            obj = self.evaluate(target.object, env)
            if isinstance(obj, dict): obj[target.name] = value
            else:
                try: setattr(obj, target.name, value)
                except (AttributeError, TypeError) as error: raise ReflexRuntimeError(f"cannot assign property {target.name}: {error}") from error
            return value
        if isinstance(target, ast.Index):
            obj, index = self.evaluate(target.object, env), self.evaluate(target.index, env)
            try: obj[index] = value
            except (KeyError, IndexError, TypeError) as error: raise ReflexRuntimeError(f"cannot assign index: {error}") from error
            return value
        raise ReflexRuntimeError("invalid assignment target")

    def call_value(self, callee: Any, args: list[Any]) -> Any:
        if not callable(callee):
            raise ReflexRuntimeError(f"{stringify(callee)} is not callable")
        try:
            return callee(*args)
        except ReflexRuntimeError:
            raise
        except TypeError as error:
            raise ReflexRuntimeError(f"invalid call: {error}") from error

    def get_member(self, obj: Any, name: str) -> Any:
        if isinstance(obj, dict):
            if name in obj: return obj[name]
            methods = {
                "keys": lambda: list(obj.keys()), "values": lambda: list(obj.values()),
                "items": lambda: [[key, value] for key, value in obj.items()],
                "get": lambda key, default=None: obj.get(key, default),
            }
            if name in methods: return methods[name]
            return None
        if isinstance(obj, list):
            methods: dict[str, Any] = {
                "length": len(obj), "push": lambda *values: (obj.extend(values) or len(obj)),
                "pop": lambda: obj.pop() if obj else None, "join": lambda separator=",": str(separator).join(stringify(v) for v in obj),
                "map": lambda fn: [self.call_value(fn, [item]) for item in obj],
                "filter": lambda fn: [item for item in obj if truthy(self.call_value(fn, [item]))],
                "includes": lambda item: item in obj, "first": obj[0] if obj else None, "last": obj[-1] if obj else None,
            }
            if name in methods: return methods[name]
        if isinstance(obj, str):
            methods = {
                "length": len(obj), "upper": obj.upper, "lower": obj.lower, "trim": obj.strip,
                "split": lambda separator=None: obj.split(separator), "includes": lambda value: str(value) in obj,
                "replace": lambda old, new: obj.replace(str(old), str(new)),
            }
            if name in methods: return methods[name]
        if obj is None:
            raise ReflexRuntimeError(f"cannot read property '{name}' of null")
        try:
            return getattr(obj, name)
        except AttributeError as error:
            raise ReflexRuntimeError(f"{type(obj).__name__} has no property '{name}'") from error

    def interpolate(self, text: str, env: Environment) -> str:
        def replace(match: re.Match[str]) -> str:
            source = match.group(1).strip()
            try:
                program = Parser(Lexer(source, "<template>").tokenize()).parse()
                if len(program.statements) != 1 or not isinstance(program.statements[0], ast.ExprStmt):
                    raise ReflexRuntimeError("template interpolation must contain one expression")
                return stringify(self.evaluate(program.statements[0].expression, env))
            except ReflexSyntaxError as error:
                raise ReflexRuntimeError(f"invalid template interpolation: {error}") from error
        return re.sub(r"\$\{(.*?)\}", replace, text, flags=re.DOTALL)


def truthy(value: Any) -> bool:
    return bool(value)


def stringify(value: Any) -> str:
    if value is None: return "null"
    if value is True: return "true"
    if value is False: return "false"
    if isinstance(value, float) and value.is_integer(): return str(int(value))
    if isinstance(value, (dict, list)): return json_module.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return str(value)
