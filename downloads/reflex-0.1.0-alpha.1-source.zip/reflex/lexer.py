"""Lexer for the Reflex language."""
from __future__ import annotations

from dataclasses import dataclass


class ReflexSyntaxError(Exception):
    """Raised when Reflex source cannot be tokenized or parsed."""

    def __init__(self, message: str, line: int, column: int = 1):
        super().__init__(f"{message} at {line}:{column}")
        self.message, self.line, self.column = message, line, column


@dataclass(frozen=True)
class Token:
    kind: str
    value: object
    line: int
    column: int


KEYWORDS = {
    "let": "LET", "const": "CONST", "fun": "FUN", "return": "RETURN",
    "if": "IF", "elif": "ELIF", "else": "ELSE", "while": "WHILE",
    "for": "FOR", "in": "IN", "break": "BREAK", "continue": "CONTINUE",
    "true": "TRUE", "false": "FALSE", "null": "NULL",
    # Python spelling is accepted too, so moving between the two styles is painless.
    "True": "TRUE", "False": "FALSE", "None": "NULL",
    "and": "AND", "or": "OR", "not": "NOT",
}


class Lexer:
    def __init__(self, source: str, filename: str = "<memory>"):
        source = source.replace("\r\n", "\n").replace("\r", "\n")
        # The line-oriented indentation lexer represents multiline literals using
        # normal escape sequences before tokenizing. The literal reader then turns
        # them back into real newlines. This keeps block indentation unambiguous.
        self.source = self._collapse_multiline_literals(source)
        self.filename = filename
        self.tokens: list[Token] = []
        self.indents = [0]
        self.group_depth = 0

    @staticmethod
    def _collapse_multiline_literals(source: str) -> str:
        result: list[str] = []
        i, n = 0, len(source)
        while i < n:
            triple = source[i:i + 3]
            delimiter = triple if triple in ('\"\"\"', "'''") else ('`' if source[i] == '`' else None)
            if delimiter is None:
                result.append(source[i])
                i += 1
                continue
            end = i + len(delimiter)
            while end < n:
                if source.startswith(delimiter, end) and (end == i + len(delimiter) or source[end - 1] != "\\"):
                    break
                end += 1
            if end >= n:
                result.append(source[i:])
                break
            content = source[i + len(delimiter):end]
            if "\n" in content:
                # Preserve backslashes before introducing our explicit newline escapes.
                content = content.replace("\\", "\\\\").replace("\n", "\\n")
            result.append(delimiter + content + delimiter)
            i = end + len(delimiter)
        return "".join(result)

    def error(self, message: str, line: int, col: int) -> None:
        raise ReflexSyntaxError(f"{self.filename}: {message}", line, col)

    def emit(self, kind: str, value: object, line: int, col: int) -> None:
        self.tokens.append(Token(kind, value, line, col))

    def tokenize(self) -> list[Token]:
        lines = self.source.splitlines()
        if self.source and not lines:
            lines = [self.source]
        for line_number, raw_line in enumerate(lines, start=1):
            self._tokenize_line(raw_line, line_number)
        if self.group_depth:
            self.error("unclosed grouping delimiter", len(lines) or 1, 1)
        last_line = len(lines) or 1
        if self.tokens and self.tokens[-1].kind != "NEWLINE":
            self.emit("NEWLINE", None, last_line, 1)
        while len(self.indents) > 1:
            self.indents.pop()
            self.emit("DEDENT", None, last_line + 1, 1)
        self.emit("EOF", None, last_line + 1, 1)
        return self.tokens

    def _tokenize_line(self, raw: str, line: int) -> None:
        # Blank and comment-only lines have no indentation meaning.
        leading = len(raw) - len(raw.lstrip(" "))
        if "\t" in raw[:leading]:
            self.error("tabs are not allowed for indentation; use spaces", line, 1)
        stripped = raw[leading:]
        if not stripped or stripped.startswith("#") or stripped.startswith("//"):
            return

        if self.group_depth == 0:
            if leading > self.indents[-1]:
                self.indents.append(leading)
                self.emit("INDENT", None, line, 1)
            else:
                while leading < self.indents[-1]:
                    self.indents.pop()
                    self.emit("DEDENT", None, line, 1)
                if leading != self.indents[-1]:
                    self.error("inconsistent indentation", line, 1)

        i = leading
        n = len(raw)
        while i < n:
            ch = raw[i]
            col = i + 1
            if ch in " \t":
                i += 1
                continue
            if ch == "#" or (ch == "/" and i + 1 < n and raw[i + 1] == "/"):
                break
            if ch.isalpha() or ch == "_":
                start = i
                i += 1
                while i < n and (raw[i].isalnum() or raw[i] == "_"):
                    i += 1
                word = raw[start:i]
                self.emit(KEYWORDS.get(word, "IDENT"), word, line, start + 1)
                continue
            if ch.isdigit() or (ch == "." and i + 1 < n and raw[i + 1].isdigit()):
                start = i
                seen_dot = ch == "."
                i += 1
                while i < n and (raw[i].isdigit() or (raw[i] == "." and not seen_dot)):
                    if raw[i] == ".":
                        seen_dot = True
                    i += 1
                text = raw[start:i]
                self.emit("NUMBER", float(text) if "." in text else int(text), line, start + 1)
                continue
            if ch in "'\"":
                value, i = self._read_string(raw, i, line, ch)
                self.emit("STRING", value, line, col)
                continue
            if ch == "`":
                value, i = self._read_template(raw, i, line)
                self.emit("TEMPLATE", value, line, col)
                continue

            pair = raw[i:i + 2]
            triples = {"=>": "ARROW", "==": "EQ", "!=": "NE", "<=": "LE", ">=": "GE",
                       "&&": "AND", "||": "OR", "+=": "PLUS_ASSIGN", "-=": "MINUS_ASSIGN",
                       "*=": "STAR_ASSIGN", "/=": "SLASH_ASSIGN"}
            singles = {"(": "LPAREN", ")": "RPAREN", "[": "LBRACKET", "]": "RBRACKET",
                       "{": "LBRACE", "}": "RBRACE", ",": "COMMA", ":": "COLON", ".": "DOT",
                       "+": "PLUS", "-": "MINUS", "*": "STAR", "/": "SLASH", "%": "PERCENT",
                       "=": "ASSIGN", "<": "LT", ">": "GT", "!": "NOT", ";": "NEWLINE"}
            if pair in triples:
                self.emit(triples[pair], pair, line, col)
                i += 2
                continue
            if ch in singles:
                kind = singles[ch]
                self.emit(kind, ch, line, col)
                if ch in "([{":
                    self.group_depth += 1
                elif ch in ")]}":
                    self.group_depth -= 1
                    if self.group_depth < 0:
                        self.error("closing delimiter without opener", line, col)
                i += 1
                continue
            self.error(f"unexpected character {ch!r}", line, col)

        if self.group_depth == 0:
            # Do not add a duplicate after a semicolon.
            if not self.tokens or self.tokens[-1].kind != "NEWLINE":
                self.emit("NEWLINE", None, line, n + 1)

    def _read_string(self, raw: str, i: int, line: int, quote: str) -> tuple[str, int]:
        start = i
        triple = raw[i:i + 3] == quote * 3
        i += 3 if triple else 1
        chars: list[str] = []
        while i < len(raw):
            if triple and raw[i:i + 3] == quote * 3:
                return "".join(chars), i + 3
            if not triple and raw[i] == quote:
                return "".join(chars), i + 1
            if raw[i] == "\\":
                i += 1
                if i >= len(raw):
                    self.error("unfinished escape sequence", line, len(raw))
                escapes = {"n": "\n", "r": "\r", "t": "\t", "\\": "\\", "'": "'", '"': '"'}
                chars.append(escapes.get(raw[i], raw[i]))
                i += 1
            else:
                chars.append(raw[i])
                i += 1
        self.error("unterminated string", line, start + 1)
        return "", i

    def _read_template(self, raw: str, i: int, line: int) -> tuple[str, int]:
        start = i
        i += 1
        chars: list[str] = []
        while i < len(raw):
            if raw[i] == "`":
                return "".join(chars), i + 1
            if raw[i] == "\\" and i + 1 < len(raw):
                i += 1
                chars.append({"n": "\n", "t": "\t", "`": "`"}.get(raw[i], raw[i]))
                i += 1
            else:
                chars.append(raw[i])
                i += 1
        self.error("unterminated template string", line, start + 1)
        return "", i
