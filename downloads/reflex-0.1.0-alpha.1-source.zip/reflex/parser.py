"""Recursive-descent parser and AST definitions for Reflex."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .lexer import Token, ReflexSyntaxError


# --- AST --------------------------------------------------------------------
@dataclass
class Program: statements: list[Any]
@dataclass
class VarDecl: name: str; value: Any; constant: bool
@dataclass
class FunctionDecl: name: str; params: list[tuple[str, Any]]; body: Any; expression_body: bool
@dataclass
class Return: value: Any | None
@dataclass
class If: branches: list[tuple[Any, list[Any]]]; otherwise: list[Any] | None
@dataclass
class While: condition: Any; body: list[Any]
@dataclass
class For: name: str; iterable: Any; body: list[Any]
@dataclass
class Break: pass
@dataclass
class Continue: pass
@dataclass
class ExprStmt: expression: Any
@dataclass
class Assignment: target: Any; operator: str; value: Any

@dataclass
class Literal: value: Any
@dataclass
class Template: text: str
@dataclass
class Identifier: name: str
@dataclass
class ListExpr: values: list[Any]
@dataclass
class ObjectExpr: pairs: list[tuple[str, Any]]
@dataclass
class Unary: operator: str; right: Any
@dataclass
class Binary: left: Any; operator: str; right: Any
@dataclass
class Call: callee: Any; args: list[Any]
@dataclass
class Member: object: Any; name: str
@dataclass
class Index: object: Any; index: Any
@dataclass
class FunctionExpr: params: list[tuple[str, Any]]; body: Any; expression_body: bool


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.current = 0

    def parse(self) -> Program:
        statements: list[Any] = []
        self.skip_newlines()
        while not self.at("EOF"):
            statements.append(self.statement())
            self.skip_newlines()
        return Program(statements)

    def statement(self) -> Any:
        # The shortest function form omits `fun` entirely:
        #   greet(name) => `Hi, ${name}`
        #   greet(name):
        #       return `Hi, ${name}`
        if self._looks_like_short_function_declaration():
            name = self.advance().value
            params = self.parameters()
            body, expression_body = self.function_body()
            if expression_body:
                self.end_statement()
            return FunctionDecl(name, params, body, expression_body)
        if self.match("LET", "CONST"):
            constant = self.previous().kind == "CONST"
            name = self.consume("IDENT", "expected a name after let/const").value
            self.consume("ASSIGN", "a declaration needs an initial value")
            value = self.expression()
            self.end_statement()
            return VarDecl(name, value, constant)
        if self.match("FUN") and self.at("IDENT"):
            name = self.advance().value
            params = self.parameters()
            body, expression_body = self.function_body()
            return FunctionDecl(name, params, body, expression_body)
        if self.previous_is("FUN"):
            # `fun` starts an anonymous expression, not a standalone statement.
            self.current -= 1
        if self.match("RETURN"):
            value = None if self.at("NEWLINE", "DEDENT", "EOF") else self.expression()
            self.end_statement()
            return Return(value)
        if self.match("IF"):
            return self.if_statement()
        if self.match("WHILE"):
            condition = self.expression()
            body = self.suite()
            return While(condition, body)
        if self.match("FOR"):
            name = self.consume("IDENT", "expected a loop variable after for").value
            self.consume("IN", "expected 'in' after the loop variable")
            iterable = self.expression()
            body = self.suite()
            return For(name, iterable, body)
        if self.match("BREAK"):
            self.end_statement()
            return Break()
        if self.match("CONTINUE"):
            self.end_statement()
            return Continue()

        expression = self.expression()
        if self.match("ASSIGN", "PLUS_ASSIGN", "MINUS_ASSIGN", "STAR_ASSIGN", "SLASH_ASSIGN"):
            if not isinstance(expression, (Identifier, Member, Index)):
                self.fail("assignment target must be a variable, property, or indexed item")
            op = self.previous().kind
            value = self.expression()
            self.end_statement()
            return Assignment(expression, op, value)
        self.end_statement()
        return ExprStmt(expression)

    def if_statement(self) -> If:
        condition = self.expression()
        branches = [(condition, self.suite())]
        while self.match("ELIF"):
            condition = self.expression()
            branches.append((condition, self.suite()))
        otherwise = None
        if self.match("ELSE"):
            otherwise = self.suite()
        return If(branches, otherwise)

    def suite(self) -> list[Any]:
        self.consume("COLON", "expected ':' before an indented block")
        self.consume("NEWLINE", "a block begins on the next line")
        self.consume("INDENT", "expected an indented block")
        statements: list[Any] = []
        self.skip_newlines()
        while not self.at("DEDENT", "EOF"):
            statements.append(self.statement())
            self.skip_newlines()
        self.consume("DEDENT", "expected end of block")
        return statements

    def function_body(self) -> tuple[Any, bool]:
        if self.match("ARROW"):
            # The surrounding statement (if any) owns the newline. This lets an
            # arrow function live naturally inside a call such as app.route(...).
            return self.expression(), True
        return self.suite(), False

    def parameters(self) -> list[tuple[str, Any]]:
        self.consume("LPAREN", "expected '(' before parameters")
        params: list[tuple[str, Any]] = []
        if not self.at("RPAREN"):
            while True:
                name = self.consume("IDENT", "expected a parameter name").value
                default = None
                if self.match("ASSIGN"):
                    default = self.expression()
                params.append((name, default))
                if not self.match("COMMA"):
                    break
                if self.at("RPAREN"):
                    break
        self.consume("RPAREN", "expected ')' after parameters")
        return params

    # Precedence ladder: or -> and -> equality -> comparison -> term -> factor.
    def expression(self) -> Any:
        return self.logic_or()

    def logic_or(self) -> Any:
        expr = self.logic_and()
        while self.match("OR"):
            expr = Binary(expr, self.previous().kind, self.logic_and())
        return expr

    def logic_and(self) -> Any:
        expr = self.equality()
        while self.match("AND"):
            expr = Binary(expr, self.previous().kind, self.equality())
        return expr

    def equality(self) -> Any:
        expr = self.comparison()
        while self.match("EQ", "NE"):
            expr = Binary(expr, self.previous().kind, self.comparison())
        return expr

    def comparison(self) -> Any:
        expr = self.term()
        while self.match("LT", "LE", "GT", "GE", "IN"):
            expr = Binary(expr, self.previous().kind, self.term())
        return expr

    def term(self) -> Any:
        expr = self.factor()
        while self.match("PLUS", "MINUS"):
            expr = Binary(expr, self.previous().kind, self.factor())
        return expr

    def factor(self) -> Any:
        expr = self.unary()
        while self.match("STAR", "SLASH", "PERCENT"):
            expr = Binary(expr, self.previous().kind, self.unary())
        return expr

    def unary(self) -> Any:
        if self.match("NOT", "MINUS", "PLUS"):
            return Unary(self.previous().kind, self.unary())
        return self.call()

    def call(self) -> Any:
        expr = self.primary()
        while True:
            if self.match("LPAREN"):
                args: list[Any] = []
                if not self.at("RPAREN"):
                    while True:
                        args.append(self.expression())
                        if not self.match("COMMA"):
                            break
                        if self.at("RPAREN"):
                            break
                self.consume("RPAREN", "expected ')' after arguments")
                expr = Call(expr, args)
            elif self.match("DOT"):
                name = self.consume("IDENT", "expected a property name after '.'").value
                expr = Member(expr, name)
            elif self.match("LBRACKET"):
                index = self.expression()
                self.consume("RBRACKET", "expected ']' after index")
                expr = Index(expr, index)
            else:
                break
        return expr

    def primary(self) -> Any:
        if self.match("NUMBER", "STRING"):
            return Literal(self.previous().value)
        if self.match("TEMPLATE"):
            return Template(self.previous().value)
        if self.match("TRUE"):
            return Literal(True)
        if self.match("FALSE"):
            return Literal(False)
        if self.match("NULL"):
            return Literal(None)
        if self.match("IDENT"):
            return Identifier(self.previous().value)
        if self.match("LPAREN"):
            expr = self.expression()
            self.consume("RPAREN", "expected ')' after expression")
            return expr
        if self.match("LBRACKET"):
            values: list[Any] = []
            if not self.at("RBRACKET"):
                while True:
                    values.append(self.expression())
                    if not self.match("COMMA"):
                        break
                    if self.at("RBRACKET"):
                        break
            self.consume("RBRACKET", "expected ']' after array")
            return ListExpr(values)
        if self.match("LBRACE"):
            pairs: list[tuple[str, Any]] = []
            if not self.at("RBRACE"):
                while True:
                    if self.match("STRING", "IDENT"):
                        key = str(self.previous().value)
                    else:
                        self.fail("object keys must be a quoted string or name")
                    self.consume("COLON", "expected ':' after object key")
                    pairs.append((key, self.expression()))
                    if not self.match("COMMA"):
                        break
                    if self.at("RBRACE"):
                        break
            self.consume("RBRACE", "expected '}' after object")
            return ObjectExpr(pairs)
        if self.match("FUN"):
            params = self.parameters()
            body, expression_body = self.function_body()
            return FunctionExpr(params, body, expression_body)
        self.fail("expected an expression")

    # --- token helpers ------------------------------------------------------
    def _looks_like_short_function_declaration(self) -> bool:
        """Recognize `name(params) => ...` / `name(params): ...` without
        mistaking an ordinary call for a declaration.
        """
        if not self.at("IDENT") or self.current + 1 >= len(self.tokens) or self.tokens[self.current + 1].kind != "LPAREN":
            return False
        depth = 0
        index = self.current + 1
        while index < len(self.tokens):
            kind = self.tokens[index].kind
            if kind == "LPAREN":
                depth += 1
            elif kind == "RPAREN":
                depth -= 1
                if depth == 0:
                    next_index = index + 1
                    return next_index < len(self.tokens) and self.tokens[next_index].kind in {"ARROW", "COLON"}
            elif kind in {"NEWLINE", "EOF"} and depth == 0:
                return False
            index += 1
        return False

    def at(self, *kinds: str) -> bool:
        return self.peek().kind in kinds

    def match(self, *kinds: str) -> bool:
        if self.at(*kinds):
            self.advance()
            return True
        return False

    def consume(self, kind: str, message: str) -> Token:
        if self.at(kind):
            return self.advance()
        self.fail(message)

    def advance(self) -> Token:
        if not self.at("EOF"):
            self.current += 1
        return self.previous()

    def peek(self) -> Token:
        return self.tokens[self.current]

    def previous(self) -> Token:
        return self.tokens[self.current - 1]

    def previous_is(self, kind: str) -> bool:
        return self.current > 0 and self.previous().kind == kind

    def skip_newlines(self) -> None:
        while self.match("NEWLINE"):
            pass

    def end_statement(self) -> None:
        if self.match("NEWLINE"):
            self.skip_newlines()
            return
        if self.at("DEDENT", "EOF"):
            return
        self.fail("expected end of statement")

    def fail(self, message: str) -> None:
        token = self.peek()
        raise ReflexSyntaxError(message, token.line, token.column)
